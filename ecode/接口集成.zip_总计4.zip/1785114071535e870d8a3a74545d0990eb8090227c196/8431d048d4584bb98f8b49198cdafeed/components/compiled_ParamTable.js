"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Table = _antd.Table,
    Switch = _antd.Switch;
/**
 * 重写 Acton 参数列表 table，自动获取 Action 中定义的参数
 * 当组件加载时，将会调用二开接口，获取 Action 中的所有参数
 */

var ParamTable =
/*#__PURE__*/
function (_React$Component) {
  _inherits(ParamTable, _React$Component);

  function ParamTable(props) {
    var _this;

    _classCallCheck(this, ParamTable);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ParamTable).call(this, props));
    console.log('props', props);
    _this.state = {
      data: props.dataSource ? props.dataSource : []
    };
    return _this;
  }

  _createClass(ParamTable, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      // 组件加载时获取流程 Action 参数
      if (this.props.classPath) {
        this.getActionParams(this.props.classPath).then(function (params) {
          var data = _this2.state.data;

          var newData = _this2.changeParams(params, data);

          _this2.setState({
            data: newData
          });
        });
      }
    }
    /**
     * 修改原 table 组件数据（action 参数），如果从接口获取的 action 参数存在原 table 数据中，则更新数据，否则添加数据
     * @param params        从接口获取的 Action 参数
     * @param originalData  原组件数据
     */

  }, {
    key: "changeParams",
    value: function changeParams(params, originalData) {
      var newData = originalData;
      params.forEach(function (i) {
        var existParam = originalData.find(function (d) {
          return d.fieldname === i.paramName;
        });

        if (existParam) {
          existParam.required = i.required;
          existParam.desc = i.desc;
          existParam.defaultValue = i.defaultValue;
          return;
        }

        originalData.push({
          required: i.required,
          desc: i.desc,
          fieldname: i.paramName,
          id: i.paramName,
          fieldvalue: i.required ? '' : i.defaultValue,
          defaultValue: i.defaultValue,
          isdatasource: '0'
        });
      });
      return newData;
    }
    /**
     * 调用接口获取 Action 参数
     */

  }, {
    key: "getActionParams",
    value: async function getActionParams(classPath) {
      var response = await fetch('/api/second-dev/extend/workflow-action-param?actionPath=' + classPath, {
        method: 'GET'
      });
      return response.json();
    }
    /**
     * 组件接收新参数时更新组件数据
     */

  }, {
    key: "componentWillReceiveProps",
    value: function componentWillReceiveProps(newProps) {
      console.log('接收新参数');

      if (newProps.dataSource) {
        this.setState({
          data: newProps.dataSource
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      var newCols = [{
        title: '是否必填',
        key: 'required',
        dataIndex: 'required',
        width: 60,
        render: function render(text, record) {
          return React.createElement(Switch, {
            checked: text,
            disabled: true
          });
        }
      }, {
        title: '描述',
        key: 'desc',
        dataIndex: 'desc',
        width: 150
      }, {
        title: '默认值',
        key: 'defaultValue',
        dataIndex: 'defaultValue',
        width: 100
      }];
      var columns = [].concat(_toConsumableArray(this.props.columns), newCols);
      return React.createElement(React.Fragment, null, React.createElement(Table, _extends({}, this.props, {
        dataSource: this.state.data,
        columns: columns,
        _noOverwirite: true
      })));
    }
  }]);

  return ParamTable;
}(React.Component);

ecodeSDK.setCom('${appId}', 'ParamTable', ParamTable);
