
const ApiList = ecodeSDK.imp(ApiList);
const MappingConfList = ecodeSDK.imp(MappingConfList);

class Index extends React.Component{
  constructor(props){
    super(props);
    this.state={
      currentKey:'1'
    }
  }

  handleClick = (e)=>{
    this.setState({
      currentKey: e.key,
    });
  }

  getContent = (key) =>{
    switch(key){
      case '1':
        return <ApiList />
      case '2':
        return <MappingConfList />
      default:
        return <ApiList />;
    }
  }


  render(){
    const {currentKey} = this.state;

    return(
      <div style={{display:'flex',height:'100%'}}>
      <Menu onClick={this.handleClick}
          style={{ width: 240 ,height :'100%'}}
          selectedKeys={[this.state.current]}
          mode="inline"
        >
          <Menu.Item key="1">接口列表</Menu.Item>
          <Menu.Item key="2">接口参数映射</Menu.Item>
        </Menu>
        <div style={{width:'100%',height:'100%'}}>
            {this.getContent(currentKey)}
        </div>
      </div>
    )
  }
}

ecodeSDK.setCom('${appId}','Index',Index);
