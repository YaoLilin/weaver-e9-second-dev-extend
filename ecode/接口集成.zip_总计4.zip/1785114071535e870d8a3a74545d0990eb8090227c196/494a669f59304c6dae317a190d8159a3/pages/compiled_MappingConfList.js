"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Table = _antd.Table,
    Button = _antd.Button,
    message = _antd.message;
var MappingDialog = ecodeSDK.imp(MappingDialog);

var MappingConfList =
/*#__PURE__*/
function (_React$Component) {
  _inherits(MappingConfList, _React$Component);

  function MappingConfList(props) {
    var _this;

    _classCallCheck(this, MappingConfList);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(MappingConfList).call(this, props));
    _this.columns = [{
      title: '唯一标识',
      dataIndex: 'confId'
    }, {
      title: '配置名称',
      dataIndex: 'name',
      render: function render(text, data) {
        return React.createElement("span", {
          style: {
            color: 'rgb(77, 122, 216)',
            cursor: 'pointer'
          },
          onClick: function onClick() {
            return _this.handleClickName(data.id);
          }
        }, text);
      }
    }, {
      title: '数据来源',
      dataIndex: 'resourceType',
      render: function render(value) {
        return value === 1 ? '建模' : '流程';
      }
    }, {
      title: '数据来源名称',
      dataIndex: 'resourceTypeName'
    }, {
      title: '接口名称',
      dataIndex: 'interfaceName'
    }];

    _this.handleClickName = function (id) {
      _this.loadMappingDetail(id);
    };

    _this.handleDialogOk = function () {
      _this.setState({
        dialogVisible: false
      }, function () {
        _this.loadMappingList(_this.state.pageNo, _this.state.pageSize);
      });
    };

    _this.handleDialogCancel = function () {
      _this.setState({
        dialogVisible: false
      });
    };

    _this.handleClickAdd = function () {
      _this.setState({
        dialogVisible: true,
        isCreate: true,
        confData: {
          confId: '',
          name: '',
          workflow: {
            id: '',
            name: ''
          },
          api: {
            id: '',
            name: ''
          },
          modelInfo: {
            id: '',
            modeName: '',
            tableName: ''
          },
          dataSource: 'workflow',
          formId: '',
          bodyType: 0,
          bodyDetailNum: null,
          mappingData: {
            bodyParameters: [],
            queryParameters: [],
            headerParameters: []
          }
        }
      });
    };

    _this.handleConfigChange = function (newData) {
      _this.setState({
        confData: newData
      });
    };

    _this.loadMappingList = function (pageNo, pageSize) {
      var url = '/api/second-dev/extend/apis/mapping?pageNo=' + pageNo + '&pageSize=' + pageSize;
      fetch(url, {
        method: 'GET'
      }).then(function (res) {
        return res.json();
      }).then(function (result) {
        var data = result && result.success && result.data ? result.data : result;
        var list = data && data.list ? data.list : [];

        _this.setState({
          list: list,
          total: data.total || 0,
          pageNo: data.pageNo || pageNo,
          pageSize: data.pageSize || pageSize
        });
      }).catch(function () {
        message.error('获取映射配置列表失败');
      });
    };

    _this.loadMappingDetail = function (id) {
      if (!id) {
        return;
      }

      var detailUrl = '/api/second-dev/extend/apis/mapping/' + encodeURIComponent(id);
      fetch(detailUrl, {
        method: 'GET'
      }).then(function (res) {
        return res.json();
      }).then(function (result) {
        var detail = result && result.success && result.data ? result.data : result;

        if (!detail) {
          message.error('获取配置详情失败');
          return;
        }

        _this.loadInterfaceConf(detail);
      }).catch(function () {
        message.error('获取配置详情失败');
      });
    };

    _this.loadInterfaceConf = function (detail) {
      var interfaceId = detail.interfaceId;

      if (!interfaceId) {
        message.error('接口信息缺失');
        return;
      }

      fetch('/api/second-dev/extend/apis/' + interfaceId, {
        method: 'GET'
      }).then(function (res) {
        return res.json();
      }).then(function (result) {
        var conf = result && result.data ? result.data : result;

        if (!conf) {
          message.error('获取接口参数配置失败');
          return;
        }

        var bodyType = conf.bodyType !== undefined && conf.bodyType !== null ? conf.bodyType : 0;
        var bodyDetailNum = detail.bodyDetailNum !== undefined ? detail.bodyDetailNum : null;
        var mappingData = {
          headerParameters: _this.normalizeInterfaceParams(conf.headerParameters, false),
          queryParameters: _this.normalizeInterfaceParams(conf.queryParameters, false),
          bodyParameters: _this.normalizeInterfaceParams(conf.bodyParameters, true)
        };

        var assignmentMap = _this.buildAssignmentMap(detail.mappings || []);

        _this.applyAssignments(mappingData.headerParameters, assignmentMap);

        _this.applyAssignments(mappingData.queryParameters, assignmentMap);

        _this.applyAssignments(mappingData.bodyParameters, assignmentMap);

        var dataSource = detail.resourceType === 1 ? 'model' : 'workflow';

        _this.setState({
          dialogVisible: true,
          isCreate: false,
          confData: {
            confId: detail.confId || '',
            name: detail.name || '',
            workflow: {
              id: detail.workflowId || '',
              name: detail.workflowName || ''
            },
            api: {
              id: detail.interfaceId || '',
              name: detail.interfaceName || ''
            },
            modelInfo: {
              id: detail.modeId || '',
              modeName: detail.modeName || '',
              tableName: detail.tableName || ''
            },
            dataSource: dataSource,
            formId: detail.workflowFormId || '',
            bodyType: bodyType,
            bodyDetailNum: bodyType === 1 ? bodyDetailNum : null,
            mappingData: mappingData
          }
        });
      }).catch(function () {
        message.error('获取接口参数配置失败');
      });
    };

    _this.normalizeInterfaceParams = function (parameters, allowChildren) {
      if (!parameters || !Array.isArray(parameters)) {
        return [];
      }

      return parameters.map(function (param) {
        var id = param.id !== undefined && param.id !== null ? String(param.id) : Date.now() + Math.random() + '';
        var type = param.type !== undefined && param.type !== null ? parseInt(param.type, 10) : 0;
        var children = allowChildren ? _this.normalizeInterfaceParams(param.children, allowChildren) : [];
        return {
          id: id,
          name: param.name || '',
          showName: param.showName || '',
          required: param.required === 1 || param.required === true,
          type: isNaN(type) ? 0 : type,
          children: children && children.length > 0 ? children : undefined
        };
      });
    };

    _this.buildAssignmentMap = function (mappings) {
      var map = {};
      mappings.forEach(function (item) {
        if (item.paramId) {
          map[item.paramId] = {
            assignment: item.assignment || null,
            detailNum: item.detailNum
          };
        }
      });
      return map;
    };

    _this.applyAssignments = function (params, assignmentMap) {
      if (!params || params.length === 0) {
        return;
      }

      params.forEach(function (param) {
        if (assignmentMap[param.id]) {
          var mapping = assignmentMap[param.id];

          if (mapping.assignment) {
            param.assignment = mapping.assignment;
          }

          if (mapping.detailNum !== undefined && mapping.detailNum !== null && mapping.detailNum !== 0) {
            param.detailNum = mapping.detailNum;
          }
        }

        if (param.children && param.children.length > 0) {
          _this.applyAssignments(param.children, assignmentMap);
        }
      });
    };

    _this.state = {
      list: [],
      pageNo: 1,
      pageSize: 10,
      total: 0,
      dialogVisible: false,
      confData: {
        confId: '',
        name: '',
        workflow: {
          id: '',
          name: ''
        },
        api: {
          id: '',
          name: ''
        },
        modelInfo: {
          id: '',
          modeName: '',
          tableName: ''
        },
        dataSource: 'workflow',
        formId: '',
        bodyType: 0,
        bodyDetailNum: null,
        mappingData: {
          bodyParameters: [],
          queryParameters: [],
          headerParameters: []
        }
      },
      isCreate: false
    };
    return _this;
  }

  _createClass(MappingConfList, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.loadMappingList(1, this.state.pageSize);
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var _this$state = this.state,
          dialogVisible = _this$state.dialogVisible,
          confData = _this$state.confData,
          isCreate = _this$state.isCreate,
          list = _this$state.list,
          pageNo = _this$state.pageNo,
          pageSize = _this$state.pageSize,
          total = _this$state.total;
      return React.createElement("div", {
        style: {
          padding: 20
        }
      }, React.createElement("div", {
        style: {
          marginBottom: 10,
          textAlign: 'right'
        }
      }, React.createElement(Button, {
        type: 'primary',
        onClick: function onClick() {
          _this2.handleClickAdd();
        }
      }, "\u6DFB\u52A0")), React.createElement(Table, {
        columns: this.columns,
        dataSource: list,
        pagination: {
          current: pageNo,
          pageSize: pageSize,
          total: total,
          showSizeChanger: true,
          onChange: function onChange(page, size) {
            return _this2.loadMappingList(page, size);
          },
          onShowSizeChange: function onShowSizeChange(page, size) {
            return _this2.loadMappingList(page, size);
          }
        },
        rowKey: "confId"
      }), React.createElement(MappingDialog, {
        visible: dialogVisible,
        data: confData,
        isCreate: isCreate,
        onOk: this.handleDialogOk,
        onChange: this.handleConfigChange,
        onCancel: this.handleDialogCancel
      }));
    }
  }]);

  return MappingConfList;
}(React.Component);

ecodeSDK.setCom('${appId}', 'MappingConfList', MappingConfList);
