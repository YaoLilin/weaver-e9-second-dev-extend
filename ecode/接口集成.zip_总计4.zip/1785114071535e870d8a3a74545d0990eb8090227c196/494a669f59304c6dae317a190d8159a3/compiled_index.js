"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var ApiList = ecodeSDK.imp(ApiList);
var MappingConfList = ecodeSDK.imp(MappingConfList);

var Index =
/*#__PURE__*/
function (_React$Component) {
  _inherits(Index, _React$Component);

  function Index(props) {
    var _this;

    _classCallCheck(this, Index);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(Index).call(this, props));

    _this.handleClick = function (e) {
      _this.setState({
        currentKey: e.key
      });
    };

    _this.getContent = function (key) {
      switch (key) {
        case '1':
          return React.createElement(ApiList, null);

        case '2':
          return React.createElement(MappingConfList, null);

        default:
          return React.createElement(ApiList, null);
      }
    };

    _this.state = {
      currentKey: '1'
    };
    return _this;
  }

  _createClass(Index, [{
    key: "render",
    value: function render() {
      var currentKey = this.state.currentKey;
      return React.createElement("div", {
        style: {
          display: 'flex',
          height: '100%'
        }
      }, React.createElement(Menu, {
        onClick: this.handleClick,
        style: {
          width: 240,
          height: '100%'
        },
        selectedKeys: [this.state.current],
        mode: "inline"
      }, React.createElement(Menu.Item, {
        key: "1"
      }, "\u63A5\u53E3\u5217\u8868"), React.createElement(Menu.Item, {
        key: "2"
      }, "\u63A5\u53E3\u53C2\u6570\u6620\u5C04")), React.createElement("div", {
        style: {
          width: '100%',
          height: '100%'
        }
      }, this.getContent(currentKey)));
    }
  }]);

  return Index;
}(React.Component);

ecodeSDK.setCom('${appId}', 'Index', Index);
