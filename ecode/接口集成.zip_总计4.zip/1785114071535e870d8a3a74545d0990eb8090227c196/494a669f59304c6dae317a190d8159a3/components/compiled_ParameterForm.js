"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Input = _antd.Input,
    Select = _antd.Select;
var _ecCom = ecCom,
    WeaFormItem = _ecCom.WeaFormItem,
    WeaForm = _ecCom.WeaForm,
    WeaInput = _ecCom.WeaInput;

var ParameterForm =
/*#__PURE__*/
function (_React$Component) {
  _inherits(ParameterForm, _React$Component);

  function ParameterForm() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, ParameterForm);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ParameterForm)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _this.handleApiUrlChange = function (v) {
      var _this$props = _this.props,
          data = _this$props.data,
          onChange = _this$props.onChange;

      var newData = _objectSpread({}, data);

      newData.url = v;
      onChange(newData);
    };

    _this.handleApiIdChange = function (v) {
      var _this$props2 = _this.props,
          data = _this$props2.data,
          onChange = _this$props2.onChange;

      var newData = _objectSpread({}, data);

      newData.apiId = v;
      onChange(newData);
    };

    _this.handleMethodChange = function (v) {
      var _this$props3 = _this.props,
          data = _this$props3.data,
          onChange = _this$props3.onChange;

      var newData = _objectSpread({}, data);

      newData.method = v;
      onChange(newData);
    };

    _this.handleNameChange = function (v) {
      var _this$props4 = _this.props,
          data = _this$props4.data,
          onChange = _this$props4.onChange;

      var newData = _objectSpread({}, data);

      newData.name = v;
      onChange(newData);
    };

    return _this;
  }

  _createClass(ParameterForm, [{
    key: "render",
    value: function render() {
      var _this$props5 = this.props,
          _this$props5$data = _this$props5.data,
          apiId = _this$props5$data.apiId,
          name = _this$props5$data.name,
          url = _this$props5$data.url,
          method = _this$props5$data.method,
          onChange = _this$props5.onChange;
      var methodValue = method !== undefined && method !== null ? Number(method) : undefined;
      console.log('methodValue:', methodValue);
      return React.createElement("div", {
        style: {
          maxWidth: 600
        }
      }, React.createElement(WeaFormItem, {
        label: "\u63A5\u53E3\u6807\u8BC6",
        labelCol: {
          span: 6
        },
        wrapperCol: {
          span: 18
        },
        viewAttr: 3,
        style: {
          padding: '10px 0'
        }
      }, React.createElement(WeaInput, {
        viewAttr: "3",
        value: apiId,
        onChange: this.handleApiIdChange,
        style: {
          width: '100%'
        }
      })), React.createElement(WeaFormItem, {
        label: "\u63A5\u53E3\u540D\u79F0",
        labelCol: {
          span: 6
        },
        wrapperCol: {
          span: 18
        },
        viewAttr: 3,
        style: {
          padding: '10px 0'
        }
      }, React.createElement(WeaInput, {
        viewAttr: "3",
        value: name,
        onChange: this.handleNameChange,
        style: {
          width: '100%'
        }
      })), React.createElement(WeaFormItem, {
        label: "\u63A5\u53E3\u5730\u5740",
        labelCol: {
          span: 6
        },
        wrapperCol: {
          span: 18
        },
        viewAttr: 3,
        style: {
          padding: '10px 0'
        }
      }, React.createElement(WeaInput, {
        viewAttr: "3",
        value: url,
        onChange: this.handleApiUrlChange,
        placeholder: "\u8BF7\u8F93\u5165\u63A5\u53E3\u5730\u5740",
        style: {
          width: '100%'
        }
      })), React.createElement(WeaFormItem, {
        label: "\u8BF7\u6C42\u65B9\u6CD5",
        labelCol: {
          span: 6
        },
        wrapperCol: {
          span: 18
        },
        viewAttr: 3,
        style: {
          padding: '10px 0'
        }
      }, React.createElement(Select, {
        style: {
          width: 200
        },
        value: methodValue,
        onChange: this.handleMethodChange
      }, React.createElement(Option, {
        value: 0
      }, "GET"), React.createElement(Option, {
        value: 1
      }, "POST"), React.createElement(Option, {
        value: 2
      }, "PUT"), React.createElement(Option, {
        value: 3
      }, "DELETE"))));
    }
  }]);

  return ParameterForm;
}(React.Component);

ecodeSDK.exp(ParameterForm);
