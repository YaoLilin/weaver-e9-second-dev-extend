"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Input = _antd.Input,
    Select = _antd.Select,
    Button = _antd.Button,
    Table = _antd.Table,
    Switch = _antd.Switch,
    Icon = _antd.Icon,
    message = _antd.message;
var Option = Select.Option;
var COMMON_COMPONENT_APP_ID = '812a0239c1e7469eb27e635cb619a2cb';
var PropTypes = window.PropTypes;
/**
 * 参数表格组件，用于在接口参数配置页面中，显示接口参数列表
 * props: {
 *     type?: 'api' | 'mapper',
 *     data?: [],
 *     onChange?: (data) => {},
 *     lockBaseFields?: boolean,
 *     disableAddDelete?: boolean,
 *     workflowId?: number | string,
 *     assignmentData?: {
 *         formFields: { mainFields: [], details: [] },
 *         systemParams: []
 *     }
 * }
 */

var ParametersTable =
/*#__PURE__*/
function (_React$Component) {
  _inherits(ParametersTable, _React$Component);

  function ParametersTable(props) {
    var _this;

    _classCallCheck(this, ParametersTable);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ParametersTable).call(this, props));

    _this.buildAssignmentValue = function (assignment) {
      if (!assignment) {
        return {
          method: 1,
          value: {
            workflowField: {},
            value: ''
          }
        };
      }

      var method = assignment.method;
      var value = assignment.value || {};

      if (method && _typeof(method) === 'object' && method.value !== undefined) {
        method = parseInt(method.value, 10);
      }

      if (method === 1 || method === 2 || method === 3) {
        return Object.assign({}, assignment, {
          method: method
        });
      }

      return {
        method: 1,
        value: {
          workflowField: {},
          value: ''
        }
      };
    };

    _this.columns = [{
      title: '参数名称',
      dataIndex: 'name',
      key: 'name',
      className: 'param-name',
      render: function render(text, record, index) {
        if (_this.props.lockBaseFields) {
          return React.createElement("div", {
            style: {
              maxWidth: 250,
              minHeight: 32,
              lineHeight: '32px'
            }
          }, text);
        }

        return React.createElement("div", {
          style: {
            maxWidth: 250,
            display: 'flex',
            alignItems: 'center'
          }
        }, React.createElement(Input, {
          value: text,
          onChange: function onChange(e) {
            return _this.handleChange(record.id, 'name', e.target.value);
          },
          onBlur: function onBlur(e) {
            return _this.handleBlur(record.id, 'name', e.target.value);
          } // 添加 onBlur 事件处理程序
          ,
          placeholder: "\u53C2\u6570\u540D\u79F0"
        }), React.createElement(Icon, {
          type: "plus-circle",
          style: {
            textAlign: 'left',
            marginLeft: '10px',
            visibility: record.type === 4 || record.type === 3 ? 'visible' : 'hidden'
          },
          onClick: function onClick() {
            return _this.handleAddParameter(record.id);
          }
        }));
      }
    }, {
      title: '显示名称',
      dataIndex: 'showName',
      key: 'showName',
      render: function render(text, record) {
        if (_this.props.lockBaseFields) {
          return React.createElement("div", {
            style: {
              maxWidth: 250,
              minHeight: 32,
              lineHeight: '32px'
            }
          }, text);
        }

        return React.createElement(Input, {
          style: {
            maxWidth: 250
          },
          value: text,
          onChange: function onChange(e) {
            return _this.handleChange(record.id, 'showName', e.target.value, 'header');
          },
          placeholder: "\u663E\u793A\u540D\u79F0"
        });
      }
    }, {
      title: '必需',
      dataIndex: 'operation',
      key: 'operation',
      render: function render(text, record) {
        return React.createElement("div", null, React.createElement(Switch, {
          checked: record.required,
          disabled: _this.props.lockBaseFields,
          onChange: function onChange(checked) {
            _this.handleChange(record.id, 'required', checked, 'header');
          }
        }));
      }
    }];

    _this.getColumns = function () {
      if (_this.props.type === 'mapper') {
        return [].concat(_toConsumableArray(_this.columns), [{
          title: '赋值',
          dataIndex: 'assignment',
          key: 'assignment',
          width: 250,
          render: function render(text, record) {
            var AssignmentCell = _this.state.AssignmentCell;

            if (!AssignmentCell) {
              return null;
            }

            return React.createElement(AssignmentCell, {
              record: record,
              value: _this.buildAssignmentValue(record.assignment),
              data: _this.props.assignmentData || {
                formFields: {
                  mainFields: [],
                  details: []
                },
                systemParams: []
              },
              onChangeAssignment: _this.handleChange
            });
          }
        }]);
      }

      return _this.columns;
    };

    _this.handleChange = function (id, field, value) {
      var _this$props = _this.props,
          data = _this$props.data,
          onChange = _this$props.onChange;
      var newData = JSON.parse(JSON.stringify(data));
      newData.forEach(function (i, index) {
        if (i.id === id) {
          i[field] = value;
        }
      });
      onChange(newData);
    };

    _this.handleBlur = function (id, field, value) {
      var _this$props2 = _this.props,
          data = _this$props2.data,
          onChange = _this$props2.onChange;
      var newData = JSON.parse(JSON.stringify(data));
      var isDuplicate = false;

      if (field === 'name' && value !== '' && i.name === value && i.id !== id) {
        isDuplicate = true;
      }

      if (isDuplicate) {
        newData.forEach(function (i, index) {
          if (i.id === id) {
            i.name = ''; // 删除重复的参数名
          }
        });
        message.error('参数名称重复，请重新输入');
      }

      onChange(newData);
    };

    _this.handleAddParameter = function () {
      var newParameter = {
        id: Date.now() + '',
        name: '',
        chineseName: '',
        required: false,
        assignment: null
      };
      var _this$props3 = _this.props,
          data = _this$props3.data,
          onChange = _this$props3.onChange;

      var newData = _toConsumableArray(data);

      newData.push(newParameter);
      onChange(newData);
    };

    _this.handleDeleteParameters = function () {
      var selectedRowKeys = _this.state.selectedRowKeys;
      var _this$props4 = _this.props,
          data = _this$props4.data,
          onChange = _this$props4.onChange;
      var newData = data.filter(function (param) {
        return !selectedRowKeys.includes(param.id);
      });
      onChange(newData);
    };

    _this.state = {
      expandedRowKeys: [],
      selectedRowKeys: [],
      AssignmentCell: null
    };
    return _this;
  }

  _createClass(ParametersTable, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      if (COMMON_COMPONENT_APP_ID) {
        ecodeSDK.load({
          id: COMMON_COMPONENT_APP_ID,
          cb: function cb() {
            _this2.setState({
              AssignmentCell: ecodeSDK.getCom(COMMON_COMPONENT_APP_ID, 'AssignmentCell')
            });
          }
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var _this$state = this.state,
          expandedRowKeys = _this$state.expandedRowKeys,
          selectedRowKeys = _this$state.selectedRowKeys;
      var _this$props5 = this.props,
          data = _this$props5.data,
          disableAddDelete = _this$props5.disableAddDelete;
      return React.createElement("div", null, !disableAddDelete && React.createElement("div", {
        style: {
          paddingBottom: 10
        }
      }, React.createElement(Button, {
        type: "primary",
        onClick: function onClick() {
          return _this3.handleAddParameter(null);
        }
      }, "\u6DFB\u52A0\u53C2\u6570"), React.createElement(Button, {
        type: "danger",
        onClick: function onClick() {
          return _this3.handleDeleteParameters();
        },
        disabled: selectedRowKeys.length === 0,
        style: {
          marginLeft: 10
        }
      }, "\u5220\u9664\u53C2\u6570")), React.createElement(Table, {
        className: 'a669f59304c6dae317a190d8159a3-table',
        columns: this.getColumns(),
        dataSource: data,
        pagination: false,
        showHeader: true,
        rowKey: "id",
        size: "small",
        indentSize: 20,
        childrenColumnName: "children",
        expandedRowKeys: expandedRowKeys,
        rowSelection: disableAddDelete ? null : {
          selectedRowKeys: selectedRowKeys,
          onChange: function onChange(selectedRowKeys) {
            return _this3.setState({
              selectedRowKeys: selectedRowKeys
            });
          }
        }
      }));
    }
  }]);

  return ParametersTable;
}(React.Component);

ParametersTable.defaultProps = {
  type: 'api',
  data: [],
  onChange: null,
  lockBaseFields: false,
  disableAddDelete: false,
  workflowId: null,
  assignmentData: {
    formFields: {
      mainFields: [],
      details: []
    },
    systemParams: []
  }
};

if (PropTypes) {
  ParametersTable.propTypes = {
    /** 表格类型(api/mapper) */
    type: PropTypes.string,

    /** 参数列表 */
    data: PropTypes.array,

    /** 数据变更回调 */
    onChange: PropTypes.func,

    /** 基础字段是否只读 */
    lockBaseFields: PropTypes.bool,

    /** 是否禁用新增/删除 */
    disableAddDelete: PropTypes.bool,

    /** 流程ID */
    workflowId: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),

    /** 赋值数据(表单字段/系统参数) */
    assignmentData: PropTypes.object
  };
}

ecodeSDK.exp(ParametersTable);
