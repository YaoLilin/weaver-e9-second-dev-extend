"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Input = _antd.Input,
    Select = _antd.Select,
    Tabs = _antd.Tabs,
    message = _antd.message;
var Option = Select.Option;
var _ecCom = ecCom,
    WeaFormItem = _ecCom.WeaFormItem,
    WeaForm = _ecCom.WeaForm,
    WeaInput = _ecCom.WeaInput;
var TabPane = Tabs.TabPane; // 引入 TabPane 组件

var ConfForm = ecodeSDK.imp(ConfForm);
var ParametersTable = ecodeSDK.imp(ParametersTable);
var COMMON_COMPONENT_APP_ID = '812a0239c1e7469eb27e635cb619a2cb';

var MappingConfig =
/*#__PURE__*/
function (_React$Component) {
  _inherits(MappingConfig, _React$Component);

  function MappingConfig(props) {
    var _this;

    _classCallCheck(this, MappingConfig);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(MappingConfig).call(this, props));

    _this.normalizeDataSource = function (value) {
      if (value === 'model') {
        return 'mode';
      }

      return value || 'workflow';
    };

    _this.resetAssignmentFormFields = function () {
      _this.setState(function (prevState) {
        return {
          assignmentData: {
            formFields: {
              mainFields: [],
              details: []
            },
            systemParams: prevState.assignmentData.systemParams || []
          }
        };
      });
    };

    _this.setAssignmentFormFields = function (formFields) {
      _this.setState(function (prevState) {
        return {
          assignmentData: {
            formFields: formFields || {
              mainFields: [],
              details: []
            },
            systemParams: prevState.assignmentData.systemParams || []
          }
        };
      });
    };

    _this.setAssignmentSystemParams = function (systemParams) {
      _this.setState(function (prevState) {
        return {
          assignmentData: {
            formFields: prevState.assignmentData.formFields || {
              mainFields: [],
              details: []
            },
            systemParams: systemParams || []
          }
        };
      });
    };

    _this.refreshAssignmentData = function (data) {
      var confData = data || {};

      var dataSource = _this.normalizeDataSource(confData.dataSource);

      var workflowId = confData.workflow && confData.workflow.id ? confData.workflow.id : null;
      var modeId = confData.modelInfo && confData.modelInfo.id ? confData.modelInfo.id : null;

      if (dataSource === 'mode') {
        _this.setAssignmentSystemParams([]);

        _this.loadModeFields(modeId);
      } else {
        _this.loadWorkflowFields(workflowId);

        _this.loadSystemParams();
      }
    };

    _this.handleHeaderParamChange = function (newData) {
      var _this$props = _this.props,
          onChange = _this$props.onChange,
          data = _this$props.data;
      var newD = JSON.parse(JSON.stringify(data));
      newD.mappingData.headerParameters = newData;
      onChange(newD);
    };

    _this.handleQueryParamChange = function (newData) {
      var _this$props2 = _this.props,
          onChange = _this$props2.onChange,
          data = _this$props2.data;
      var newD = JSON.parse(JSON.stringify(data));
      newD.mappingData.queryParameters = newData;
      onChange(newD);
    };

    _this.handleBodyParamChange = function (newData) {
      var _this$props3 = _this.props,
          onChange = _this$props3.onChange,
          data = _this$props3.data;
      var newD = JSON.parse(JSON.stringify(data));
      newD.mappingData.bodyParameters = newData;
      onChange(newD);
    };

    _this.handleFormChange = function (newData) {
      var _this$props4 = _this.props,
          onChange = _this$props4.onChange,
          data = _this$props4.data;
      var newD = JSON.parse(JSON.stringify(data));
      newD.confId = newData.confId;
      newD.name = newData.name;
      newD.api = newData.api;
      newD.workflow = newData.workflow;
      newD.formId = newData.formId;
      newD.dataSource = newData.dataSource;
      newD.modelInfo = newData.modelInfo;
      newD.bodyType = newData.bodyType;

      if (newData.bodyType !== 1) {
        newD.bodyDetailNum = null;
      }

      if (newData.mappingData) {
        newD.mappingData = newData.mappingData;
      }

      onChange(newD);

      _this.setState({
        formId: newData.formId
      });

      _this.refreshAssignmentData(newData);
    };

    _this.handleBodyDetailNumChange = function (value) {
      var _this$props5 = _this.props,
          onChange = _this$props5.onChange,
          data = _this$props5.data;
      var newD = JSON.parse(JSON.stringify(data));
      newD.bodyDetailNum = value || null;
      onChange(newD);
    };

    _this.renderBodyDetailOptions = function () {
      var assignmentData = _this.state.assignmentData;
      var details = assignmentData && assignmentData.formFields ? assignmentData.formFields.details : [];

      if (!details || details.length === 0) {
        return [];
      }

      var list = [];
      details.forEach(function (detail) {
        if (detail && detail.detailNum && detail.fields && detail.fields.length > 0) {
          var value = detail.detailNum;
          list.push(React.createElement(Option, {
            key: value,
            value: value
          }, '明细' + value));
        }
      });
      return list;
    };

    _this.state = {
      formId: '',
      ParametersMapperTable: null,
      assignmentData: {
        formFields: {
          mainFields: [],
          details: []
        },
        systemParams: []
      }
    };
    return _this;
  }

  _createClass(MappingConfig, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      if (COMMON_COMPONENT_APP_ID) {
        ecodeSDK.load({
          id: COMMON_COMPONENT_APP_ID,
          cb: function cb() {
            _this2.setState({
              ParametersMapperTable: ecodeSDK.getCom(COMMON_COMPONENT_APP_ID, 'ParametersMapperTable')
            });
          }
        });
      }

      this.refreshAssignmentData(this.props.data);
    } // 监听数据来源/流程/建模变化，变化时刷新赋值数据，避免外部更新导致字段不同步

  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      var prevData = prevProps.data || {};
      var currentData = this.props.data || {};
      var prevSource = this.normalizeDataSource(prevData.dataSource);
      var currentSource = this.normalizeDataSource(currentData.dataSource);
      var prevWorkflowId = prevData.workflow && prevData.workflow.id ? prevData.workflow.id : null;
      var currentWorkflowId = currentData.workflow && currentData.workflow.id ? currentData.workflow.id : null;
      var prevModeId = prevData.modelInfo && prevData.modelInfo.id ? prevData.modelInfo.id : null;
      var currentModeId = currentData.modelInfo && currentData.modelInfo.id ? currentData.modelInfo.id : null;

      if (prevSource !== currentSource || prevWorkflowId !== currentWorkflowId || prevModeId !== currentModeId) {
        this.refreshAssignmentData(currentData);
      }
    }
  }, {
    key: "loadWorkflowFields",
    value: async function loadWorkflowFields(workflowId) {
      if (!workflowId || workflowId <= 0) {
        this.resetAssignmentFormFields();
        return;
      }

      try {
        var response = await fetch('/api/second-dev/extend/workflow/fields?workflowId=' + workflowId, {
          method: 'GET'
        });
        var result = await response.json();

        if (result.success && result.data) {
          this.setAssignmentFormFields(result.data);
        } else {
          this.resetAssignmentFormFields();
          message.error('获取流程字段失败：' + (result.message || '未知错误'));
        }
      } catch (error) {
        this.resetAssignmentFormFields();
        message.error('获取流程字段失败：' + error.message);
      }
    }
  }, {
    key: "loadModeFields",
    value: async function loadModeFields(modeId) {
      if (!modeId || modeId <= 0) {
        this.resetAssignmentFormFields();
        return;
      }

      try {
        var response = await fetch('/api/second-dev/extend/modes/fields?modeId=' + modeId, {
          method: 'GET'
        });
        var result = await response.json();

        if (result.success && result.data) {
          this.setAssignmentFormFields(result.data);
        } else {
          this.resetAssignmentFormFields();
          message.error('获取建模字段失败：' + (result.message || '未知错误'));
        }
      } catch (error) {
        this.resetAssignmentFormFields();
        message.error('获取建模字段失败：' + error.message);
      }
    }
  }, {
    key: "loadSystemParams",
    value: async function loadSystemParams() {
      try {
        var response = await fetch('/api/second-dev/extend/workflow-action-param/system-params', {
          method: 'GET'
        });
        var result = await response.json();

        if (result.success && result.data) {
          this.setAssignmentSystemParams(result.data);
        }
      } catch (error) {
        console.error('获取系统参数失败:', error);
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$state = this.state,
          formId = _this$state.formId,
          ParametersMapperTable = _this$state.ParametersMapperTable,
          assignmentData = _this$state.assignmentData;
      var isCreate = this.props.isCreate;
      var _this$props$data = this.props.data,
          confId = _this$props$data.confId,
          name = _this$props$data.name,
          api = _this$props$data.api,
          workflow = _this$props$data.workflow,
          dataSource = _this$props$data.dataSource,
          modelInfo = _this$props$data.modelInfo;
      var _this$props$data$mapp = this.props.data.mappingData,
          queryParameters = _this$props$data$mapp.queryParameters,
          bodyParameters = _this$props$data$mapp.bodyParameters,
          headerParameters = _this$props$data$mapp.headerParameters;
      var workflowId = workflow && workflow.id ? workflow.id : null;
      var modeId = modelInfo && modelInfo.id ? modelInfo.id : null;
      var bodyType = this.props.data.bodyType !== undefined && this.props.data.bodyType !== null ? this.props.data.bodyType : 0;
      var bodyDetailNum = this.props.data.bodyDetailNum || null;
      return React.createElement("div", {
        style: {
          overflow: 'scroll',
          height: '70vh'
        }
      }, React.createElement(ConfForm, {
        data: this.props.data,
        isCreate: isCreate,
        onChange: this.handleFormChange
      }), React.createElement(Tabs, null, React.createElement(TabPane, {
        tab: "\u8BF7\u6C42\u5934\u53C2\u6570",
        key: "1"
      }, React.createElement(ParametersTable, {
        type: 'mapper',
        data: headerParameters,
        formId: formId,
        assignmentData: assignmentData,
        lockBaseFields: true,
        disableAddDelete: true,
        onChange: this.handleHeaderParamChange
      })), React.createElement(TabPane, {
        tab: "\u67E5\u8BE2\u53C2\u6570",
        key: "2"
      }, React.createElement(ParametersTable, {
        type: 'mapper',
        data: queryParameters,
        formId: formId,
        assignmentData: assignmentData,
        lockBaseFields: true,
        disableAddDelete: true,
        onChange: this.handleQueryParamChange
      })), React.createElement(TabPane, {
        tab: "\u8BF7\u6C42\u4F53\u53C2\u6570",
        key: "3"
      }, React.createElement("div", {
        style: {
          marginBottom: 12
        }
      }, React.createElement("span", {
        style: {
          marginRight: 8
        }
      }, "Body \u7C7B\u578B\uFF1A"), React.createElement(Select, {
        value: bodyType,
        style: {
          width: 160
        },
        disabled: true
      }, React.createElement(Option, {
        value: 0
      }, "\u5BF9\u8C61"), React.createElement(Option, {
        value: 1
      }, "\u6570\u7EC4")), bodyType === 1 ? React.createElement("span", {
        style: {
          marginLeft: 16
        }
      }, React.createElement("span", {
        style: {
          marginRight: 8
        }
      }, "\u660E\u7EC6\u8868\uFF1A"), React.createElement(Select, {
        value: bodyDetailNum || undefined,
        onChange: this.handleBodyDetailNumChange,
        style: {
          width: 160
        },
        allowClear: true
      }, this.renderBodyDetailOptions())) : null), ParametersMapperTable ? React.createElement(ParametersMapperTable, {
        data: bodyParameters,
        dataSource: dataSource,
        workflowId: workflowId,
        modeId: modeId,
        formId: formId,
        onChange: this.handleBodyParamChange
      }) : null)));
    }
  }]);

  return MappingConfig;
}(React.Component);

ecodeSDK.exp(MappingConfig);
