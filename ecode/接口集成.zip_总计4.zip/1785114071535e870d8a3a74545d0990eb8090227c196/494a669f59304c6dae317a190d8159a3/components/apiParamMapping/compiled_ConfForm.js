"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Input = _antd.Input,
    Select = _antd.Select,
    message = _antd.message;
var Option = Select.Option;
var _ecCom = ecCom,
    WeaFormItem = _ecCom.WeaFormItem,
    WeaForm = _ecCom.WeaForm,
    WeaInput = _ecCom.WeaInput;
var ModelInfoSelector = ecodeSDK.imp(ModelInfoSelector);
var ApiInfoSelector = ecodeSDK.imp(ApiInfoSelector);
var WorkflowInfoSelector = ecodeSDK.imp(WorkflowInfoSelector);

var ConfForm =
/*#__PURE__*/
function (_React$Component) {
  _inherits(ConfForm, _React$Component);

  function ConfForm() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, ConfForm);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ConfForm)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _this.handleChange = function (name, value) {
      var _this$props = _this.props,
          onChange = _this$props.onChange,
          data = _this$props.data;

      var newData = _objectSpread({}, data);

      newData[name] = value;
      onChange(newData);
    };

    _this.handleSelectWorkflowChange = function (value, formId) {
      var _this$props2 = _this.props,
          onChange = _this$props2.onChange,
          data = _this$props2.data;

      var newData = _objectSpread({}, data);

      newData.workflow = value;
      newData.formId = formId;
      onChange(newData);
    };

    _this.handleWorkflowInfoChange = function (workflowInfo) {
      var info = workflowInfo || {};

      _this.handleSelectWorkflowChange({
        id: info.id || '',
        name: info.workflowName || ''
      }, info.formId || '');
    };

    _this.getEmptyMappingData = function () {
      return {
        bodyParameters: [],
        queryParameters: [],
        headerParameters: []
      };
    };

    _this.normalizeInterfaceParams = function (parameters, allowChildren) {
      if (!parameters || !Array.isArray(parameters)) {
        return [];
      }

      return parameters.map(function (param) {
        var id = param.id !== undefined && param.id !== null ? String(param.id) : Date.now() + Math.random() + '';
        var type = param.type !== undefined && param.type !== null ? parseInt(param.type, 10) : 0;
        var children = allowChildren ? _this.normalizeInterfaceParams(param.children, allowChildren) : [];
        return {
          id: id,
          name: param.name || '',
          showName: param.showName || '',
          required: param.required === 1 || param.required === true,
          type: isNaN(type) ? 0 : type,
          children: children && children.length > 0 ? children : undefined
        };
      });
    };

    _this.handleSelectApiChange = async function (ids, names) {
      var _this$props3 = _this.props,
          onChange = _this$props3.onChange,
          data = _this$props3.data;

      var newData = _objectSpread({}, data);

      newData.api = {
        id: ids,
        name: names
      };

      if (!ids) {
        newData.mappingData = _this.getEmptyMappingData();
        onChange(newData);
        return;
      }

      try {
        var response = await fetch('/api/second-dev/extend/apis/' + encodeURIComponent(ids), {
          method: 'GET'
        });
        var result = await response.json();
        var conf = result && result.data ? result.data : result;

        if (!conf) {
          message.error('获取接口参数配置失败');
          return;
        }

        newData.mappingData = {
          headerParameters: _this.normalizeInterfaceParams(conf.headerParameters, false),
          queryParameters: _this.normalizeInterfaceParams(conf.queryParameters, false),
          bodyParameters: _this.normalizeInterfaceParams(conf.bodyParameters, true)
        };
        onChange(newData);
      } catch (error) {
        message.error('获取接口参数配置失败：' + error.message);
      }
    };

    _this.handleApiInfoChange = function (apiInfo) {
      var info = apiInfo || {};

      _this.handleSelectApiChange(info.id || '', info.name || '');
    };

    _this.handleDataSourceChange = function (value) {
      var _this$props4 = _this.props,
          onChange = _this$props4.onChange,
          data = _this$props4.data;

      var newData = _objectSpread({}, data);

      newData.dataSource = value;

      if (value === 'workflow') {
        newData.modelInfo = {};
      } else {
        newData.workflow = {};
        newData.formId = '';
      }

      onChange(newData);
    };

    _this.handleModelInfoChange = function (modelInfo) {
      var _this$props5 = _this.props,
          onChange = _this$props5.onChange,
          data = _this$props5.data;

      var newData = _objectSpread({}, data);

      newData.modelInfo = modelInfo;
      onChange(newData);
    };

    return _this;
  }

  _createClass(ConfForm, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var isCreate = this.props.isCreate;
      var _this$props$data = this.props.data,
          confId = _this$props$data.confId,
          name = _this$props$data.name,
          api = _this$props$data.api,
          workflow = _this$props$data.workflow;
      var dataSource = this.props.data.dataSource || 'workflow';
      var modelInfo = this.props.data.modelInfo || {};
      var modelValue = modelInfo.modeName || '';
      var needModelInfo = dataSource === 'model';
      var isModelEmpty = needModelInfo && !modelInfo.id;
      return React.createElement("div", {
        style: {
          maxWidth: 600
        }
      }, React.createElement(WeaFormItem, {
        label: "\u552F\u4E00\u6807\u8BC6",
        labelCol: {
          span: 6
        },
        wrapperCol: {
          span: 18
        },
        viewAttr: 3,
        style: {
          padding: '10px 0'
        }
      }, React.createElement(WeaInput, {
        viewAttr: isCreate ? '3' : '1',
        value: confId,
        onChange: function onChange(value) {
          _this2.handleChange('confId', value);
        },
        style: {
          width: '100%'
        }
      })), React.createElement(WeaFormItem, {
        label: "\u540D\u79F0",
        labelCol: {
          span: 6
        },
        wrapperCol: {
          span: 18
        },
        viewAttr: 3,
        style: {
          padding: '10px 0'
        }
      }, React.createElement(WeaInput, {
        viewAttr: "3",
        value: name,
        onChange: function onChange(value) {
          _this2.handleChange('name', value);
        },
        style: {
          width: '100%'
        }
      })), React.createElement(WeaFormItem, {
        label: "\u9009\u62E9\u63A5\u53E3",
        labelCol: {
          span: 6
        },
        wrapperCol: {
          span: 18
        },
        viewAttr: 3,
        style: {
          padding: '10px 0'
        }
      }, React.createElement(ApiInfoSelector, {
        value: api && api.name ? api.name : '',
        apiInfo: api || {},
        onChange: this.handleApiInfoChange
      })), React.createElement(WeaFormItem, {
        label: "\u6570\u636E\u6765\u6E90",
        labelCol: {
          span: 6
        },
        wrapperCol: {
          span: 18
        },
        viewAttr: 3,
        style: {
          padding: '10px 0'
        }
      }, React.createElement(Select, {
        value: dataSource,
        onChange: function onChange(value) {
          _this2.handleDataSourceChange(value);
        }
      }, React.createElement(Option, {
        value: "workflow"
      }, "\u6D41\u7A0B"), React.createElement(Option, {
        value: "model"
      }, "\u5EFA\u6A21"))), dataSource === 'workflow' && React.createElement(WeaFormItem, {
        label: "\u9009\u62E9\u6D41\u7A0B",
        labelCol: {
          span: 6
        },
        wrapperCol: {
          span: 18
        },
        viewAttr: 3,
        style: {
          padding: '10px 0'
        }
      }, React.createElement(WorkflowInfoSelector, {
        value: workflow && workflow.name ? workflow.name : '',
        workflowInfo: workflow || {},
        onChange: this.handleWorkflowInfoChange
      })), dataSource === 'model' && React.createElement(WeaFormItem, {
        label: "\u9009\u62E9\u5EFA\u6A21",
        labelCol: {
          span: 6
        },
        wrapperCol: {
          span: 18
        },
        viewAttr: 3,
        style: {
          padding: '10px 0'
        }
      }, React.createElement(ModelInfoSelector, {
        value: modelValue,
        modelInfo: modelInfo,
        onChange: this.handleModelInfoChange
      }), isModelEmpty ? React.createElement("div", {
        style: {
          color: '#f5222d',
          marginTop: 6
        }
      }, "\u8BF7\u9009\u62E9\u5EFA\u6A21") : null));
    }
  }]);

  return ConfForm;
}(React.Component);

ecodeSDK.exp(ConfForm);
