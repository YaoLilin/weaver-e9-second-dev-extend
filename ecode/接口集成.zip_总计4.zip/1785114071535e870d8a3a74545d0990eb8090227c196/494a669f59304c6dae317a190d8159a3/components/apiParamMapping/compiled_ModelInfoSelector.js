"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Input = _antd.Input,
    Modal = _antd.Modal,
    Table = _antd.Table,
    Button = _antd.Button,
    message = _antd.message;
var _ecCom = ecCom,
    WeaInputSearch = _ecCom.WeaInputSearch;
var PropTypes = window.PropTypes;

var ModelInfoSelector =
/*#__PURE__*/
function (_React$Component) {
  _inherits(ModelInfoSelector, _React$Component);

  function ModelInfoSelector(props) {
    var _this;

    _classCallCheck(this, ModelInfoSelector);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ModelInfoSelector).call(this, props));

    _this.handleQueryChange = function (field, value) {
      var query = _this.state.query;

      _this.setState({
        query: _objectSpread({}, query, _defineProperty({}, field, value))
      });
    };

    _this.buildQueryUrl = function (pageNo, pageSize) {
      var query = _this.state.query;
      var url = '/api/second-dev/extend/modes?pageNo=' + pageNo + '&pageSize=' + pageSize;

      if (query.id) {
        url += '&id=' + encodeURIComponent(query.id);
      }

      if (query.modeName) {
        url += '&modeName=' + encodeURIComponent(query.modeName);
      }

      if (query.tableName) {
        url += '&tableName=' + encodeURIComponent(query.tableName);
      }

      return url;
    };

    _this.fetchList = async function (pageNo) {
      var currentPage = pageNo || 1;
      var pageSize = _this.state.pageSize;

      _this.setState({
        loading: true
      });

      try {
        var url = _this.buildQueryUrl(currentPage, pageSize);

        var response = await fetch(url, {
          method: 'GET'
        });
        var result = await response.json();

        if (result && result.success && result.data) {
          _this.setState({
            list: result.data.list || [],
            total: result.data.total || 0,
            pageNo: result.data.pageNo || currentPage
          });
        } else {
          message.error('获取建模信息失败：' + (result.message || '未知错误'));
        }
      } catch (error) {
        message.error('获取建模信息失败：' + error.message);
      } finally {
        _this.setState({
          loading: false
        });
      }
    };

    _this.openDialog = function () {
      var modelInfo = _this.props.modelInfo || {};
      var selectedRowKeys = modelInfo.id ? [String(modelInfo.id)] : [];

      _this.setState({
        dialogVisible: true,
        selectedRowKeys: selectedRowKeys,
        selectedRow: modelInfo.id ? modelInfo : null
      }, function () {
        _this.fetchList(1);
      });
    };

    _this.handleSearch = function () {
      _this.fetchList(1);
    };

    _this.handleSelectChange = function (selectedRowKeys, selectedRows) {
      _this.setState({
        selectedRowKeys: selectedRowKeys,
        selectedRow: selectedRows && selectedRows.length > 0 ? selectedRows[0] : null
      });
    };

    _this.handleConfirm = function () {
      var selectedRow = _this.state.selectedRow;

      if (!selectedRow) {
        message.error('请选择一条建模数据');
        return;
      }

      if (_this.props.onChange) {
        _this.props.onChange({
          id: selectedRow.id,
          modeName: selectedRow.modeName,
          tableName: selectedRow.tableName
        });
      }

      _this.setState({
        dialogVisible: false
      });
    };

    _this.handleCancel = function () {
      _this.setState({
        dialogVisible: false
      });
    };

    _this.state = {
      displayValue: props.value || '',
      dialogVisible: false,
      loading: false,
      list: [],
      pageNo: 1,
      pageSize: 10,
      total: 0,
      query: {
        id: '',
        modeName: '',
        tableName: ''
      },
      selectedRowKeys: [],
      selectedRow: null
    };
    return _this;
  }

  _createClass(ModelInfoSelector, [{
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      if (prevProps.value !== this.props.value) {
        this.setState({
          displayValue: this.props.value || ''
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var _this$state = this.state,
          displayValue = _this$state.displayValue,
          dialogVisible = _this$state.dialogVisible,
          loading = _this$state.loading,
          list = _this$state.list,
          pageNo = _this$state.pageNo,
          pageSize = _this$state.pageSize,
          total = _this$state.total,
          query = _this$state.query,
          selectedRowKeys = _this$state.selectedRowKeys;
      return React.createElement("span", null, React.createElement(WeaInputSearch, {
        value: displayValue,
        placeholder: "\u8BF7\u9009\u62E9\u5EFA\u6A21\u4FE1\u606F",
        onSearch: this.openDialog,
        onChange: function onChange() {
          return _this2.setState({
            displayValue: _this2.props.value || ''
          });
        },
        onSearchChange: function onSearchChange() {
          return _this2.setState({
            displayValue: _this2.props.value || ''
          });
        }
      }), React.createElement(Modal, {
        title: "\u9009\u62E9\u5EFA\u6A21\u4FE1\u606F",
        visible: dialogVisible,
        onOk: this.handleConfirm,
        onCancel: this.handleCancel,
        width: 720
      }, React.createElement("div", {
        style: {
          marginBottom: 16
        }
      }, React.createElement("div", {
        style: {
          display: 'flex',
          gap: 12
        }
      }, React.createElement(Input, {
        placeholder: "\u6A21\u5757ID",
        value: query.id,
        onChange: function onChange(e) {
          return _this2.handleQueryChange('id', e.target.value);
        },
        style: {
          width: 120
        }
      }), React.createElement(Input, {
        placeholder: "\u6A21\u5757\u540D\u79F0",
        value: query.modeName,
        onChange: function onChange(e) {
          return _this2.handleQueryChange('modeName', e.target.value);
        },
        style: {
          width: 200
        }
      }), React.createElement(Input, {
        placeholder: "\u8868\u5355\u540D\u79F0",
        value: query.tableName,
        onChange: function onChange(e) {
          return _this2.handleQueryChange('tableName', e.target.value);
        },
        style: {
          width: 200
        }
      }), React.createElement(Button, {
        type: "primary",
        onClick: this.handleSearch
      }, "\u67E5\u8BE2"))), React.createElement(Table, {
        rowKey: "id",
        columns: [{
          title: '模块ID',
          dataIndex: 'id',
          key: 'id',
          width: 100
        }, {
          title: '模块名称',
          dataIndex: 'modeName',
          key: 'modeName'
        }, {
          title: '表单名称',
          dataIndex: 'tableName',
          key: 'tableName'
        }],
        dataSource: list,
        loading: loading,
        pagination: {
          current: pageNo,
          pageSize: pageSize,
          total: total,
          showSizeChanger: true,
          pageSizeOptions: ['10', '20', '50'],
          onChange: function onChange(page) {
            return _this2.fetchList(page);
          },
          onShowSizeChange: function onShowSizeChange(page, size) {
            _this2.setState({
              pageSize: size
            }, function () {
              _this2.fetchList(1);
            });
          }
        },
        rowSelection: {
          type: 'radio',
          selectedRowKeys: selectedRowKeys,
          onChange: this.handleSelectChange
        }
      })));
    }
  }]);

  return ModelInfoSelector;
}(React.Component);

if (PropTypes) {
  ModelInfoSelector.propTypes = {
    /** 输入框显示值 */
    value: PropTypes.string,

    /** 当前已选建模信息 */
    modelInfo: PropTypes.shape({
      id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
      modeName: PropTypes.string,
      tableName: PropTypes.string
    }),

    /** 选择完成回调 */
    onChange: PropTypes.func
  };
}

ModelInfoSelector.defaultProps = {
  value: '',
  modelInfo: {},
  onChange: null
};
ecodeSDK.exp(ModelInfoSelector);
ecodeSDK.setCom('${appId}', 'ModelInfoSelector', ModelInfoSelector);
