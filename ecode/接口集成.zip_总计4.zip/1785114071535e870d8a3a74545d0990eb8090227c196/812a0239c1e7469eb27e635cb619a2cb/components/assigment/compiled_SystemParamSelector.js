"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Input = _antd.Input;
/**
 * 系统参数选择器组件
 * props: {
 *     systemParams: array,  // 系统参数列表
 *     selectedParamCode: string,  // 当前选中的参数代码
 *     onParamSelect: (paramCode) => {},  // 参数选择回调
 * }
 */

var SystemParamSelector =
/*#__PURE__*/
function (_React$Component) {
  _inherits(SystemParamSelector, _React$Component);

  function SystemParamSelector(props) {
    var _this;

    _classCallCheck(this, SystemParamSelector);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(SystemParamSelector).call(this, props));

    _this.handleSearchChange = function (e) {
      _this.setState({
        searchText: e.target.value
      });
    };

    _this.state = {
      searchText: ''
    };
    return _this;
  }

  _createClass(SystemParamSelector, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          systemParams = _this$props.systemParams,
          selectedParamCode = _this$props.selectedParamCode,
          onParamSelect = _this$props.onParamSelect;
      var searchText = this.state.searchText;
      var keyword = (searchText || '').trim();
      var filteredParams = keyword ? systemParams.filter(function (s) {
        return (s.name || '').toLowerCase().includes(keyword.toLowerCase());
      }) : systemParams;

      var listItemStyle = function listItemStyle(active) {
        return {
          padding: '8px 10px',
          cursor: 'pointer',
          borderRadius: 4,
          background: active ? '#e6f7ff' : 'transparent'
        };
      };

      var listWrapStyle = {
        border: '1px solid #eee',
        borderRadius: 4,
        maxHeight: 220,
        overflowY: 'auto',
        padding: 6
      };
      return React.createElement("div", null, React.createElement("div", {
        style: {
          marginBottom: 6
        }
      }, "\u7CFB\u7EDF\u53C2\u6570"), React.createElement(Input, {
        style: {
          width: '100%',
          marginBottom: 8
        },
        value: searchText,
        placeholder: "\u641C\u7D22\u7CFB\u7EDF\u53C2\u6570",
        onChange: this.handleSearchChange
      }), React.createElement("div", {
        style: listWrapStyle
      }, filteredParams.length === 0 ? React.createElement("div", {
        style: {
          color: '#999',
          padding: '6px 4px'
        }
      }, "\u65E0\u5339\u914D\u7CFB\u7EDF\u53C2\u6570") : filteredParams.map(function (s) {
        return React.createElement("div", {
          key: s.code,
          style: listItemStyle(s.code === selectedParamCode),
          onClick: function onClick() {
            if (onParamSelect) {
              onParamSelect(s.code);
            }
          },
          title: s.name
        }, s.name);
      })));
    }
  }]);

  return SystemParamSelector;
}(React.Component);

ecodeSDK.exp(SystemParamSelector);
ecodeSDK.setCom('${appId}', 'SystemParamSelector', SystemParamSelector);
