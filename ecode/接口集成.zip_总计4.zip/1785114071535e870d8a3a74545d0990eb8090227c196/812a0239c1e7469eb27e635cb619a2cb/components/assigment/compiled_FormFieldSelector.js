"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Input = _antd.Input,
    Select = _antd.Select,
    Table = _antd.Table;
var Option = Select.Option;
/**
 * 表单字段选择器组件
 * props: {
 *     categories: array,  // 字段分类选项 [{ categoryName: '主表字段', id: 'MAIN' }, ...]
 *     fields: array,  // 当前选中分类的字段列表
 *     selectedCategory: string,  // 当前选中的分类ID
 *     selectedFieldId: string,  // 当前选中的字段ID
 *     loadingFields: boolean,  // 是否正在加载字段
 *     onCategoryChange: (categoryId) => {},  // 分类变化回调
 *     onFieldSelect: (fieldId) => {},  // 字段选择回调
 * }
 */

var FormFieldSelector =
/*#__PURE__*/
function (_React$Component) {
  _inherits(FormFieldSelector, _React$Component);

  function FormFieldSelector(props) {
    var _this;

    _classCallCheck(this, FormFieldSelector);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(FormFieldSelector).call(this, props));

    _this.handleSearchChange = function (e) {
      _this.setState({
        searchText: e.target.value
      });
    };

    _this.getOptions = function () {
      var data = _this.props.data;

      if (!data) {
        return [];
      }

      var options = [];

      if (data.mainFields) {
        options.push(React.createElement(Option, {
          key: 0,
          value: 0
        }, "\u4E3B\u8868"));
      }

      if (data.details) {
        data.details.forEach(function (detail) {
          options.push(React.createElement(Option, {
            key: detail.detailNum,
            value: detail.detailNum
          }, "\u660E\u7EC6\u8868".concat(detail.detailNum)));
        });
      }

      return options;
    };

    _this.getTableData = function () {
      var data = _this.props.data;

      if (!data) {
        return [];
      }

      var isMainTable = data.isMainTable;
      var detailTableNum = data.detailTableNum;

      if (isMainTable) {
        return data.mainFields || [];
      }

      if (detailTableNum) {
        var detail = (data.details || []).find(function (d) {
          return d.detailNum === detailTableNum;
        });
        return detail ? detail.fields || [] : [];
      }

      return [];
    };

    _this.handleCategoryChange = function (v) {
      _this.setState({
        searchText: '',
        selectedCategory: v
      });

      var onChange = _this.props.onChange;

      var newData = _objectSpread({}, _this.props.data);

      newData.isMainTable = v === 0;
      newData.detailTableNum = v === 0 ? null : v;
      onChange(newData);
    };

    var selectedCategory = 0;

    if (props.data) {
      if (props.data.isMainTable) {
        selectedCategory = 0;
      } else if (props.data.detailTableNum) {
        selectedCategory = props.data.detailTableNum;
      }
    }

    _this.state = {
      searchText: '',
      selectedCategory: selectedCategory
    };
    return _this;
  }

  _createClass(FormFieldSelector, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var _this$props = this.props,
          loadingFields = _this$props.loadingFields,
          onChange = _this$props.onChange;
      var _this$state = this.state,
          searchText = _this$state.searchText,
          selectedCategory = _this$state.selectedCategory;
      var selectedFieldId = this.props.value ? this.props.value.fieldName : '';
      var fields = this.getTableData();
      var keyword = (searchText || '').trim();
      var filteredFields = keyword ? fields.filter(function (f) {
        return (f.labelName || '').toLowerCase().includes(keyword.toLowerCase()) || (f.fieldName || '').toLowerCase().includes(keyword.toLowerCase());
      }) : fields; // Table 列定义

      var columns = [{
        title: '字段中文名',
        dataIndex: 'labelName',
        key: 'labelName',
        width: 120
      }, {
        title: '字段数据库名',
        dataIndex: 'fieldName',
        key: 'fieldName',
        width: 150
      }, {
        title: '字段类型',
        dataIndex: 'fieldType',
        key: 'fieldType',
        width: 100
      }]; // Table 行选择配置

      var rowSelection = {
        type: 'radio',
        selectedRowKeys: selectedFieldId ? [selectedFieldId] : [],
        onSelect: function onSelect(record, selected) {
          if (selected && onChange) {
            var newValue = _objectSpread({}, _this2.props.value);

            newValue.fieldName = record.fieldName;

            _this2.props.onChange(newValue);
          }
        }
      };
      return React.createElement("div", null, React.createElement("div", {
        style: {
          marginBottom: 12
        }
      }, React.createElement("div", {
        style: {
          marginBottom: 6
        }
      }, "\u5206\u7C7B"), React.createElement(Select, {
        style: {
          width: '100%'
        },
        value: selectedCategory,
        onChange: this.handleCategoryChange
      }, this.getOptions())), React.createElement("div", null, React.createElement("div", {
        style: {
          marginBottom: 6
        }
      }, "\u5B57\u6BB5"), React.createElement(Input, {
        style: {
          width: '100%',
          marginBottom: 8
        },
        value: searchText,
        placeholder: "\u641C\u7D22\u5B57\u6BB5\uFF08\u652F\u6301\u4E2D\u6587\u540D\u548C\u6570\u636E\u5E93\u540D\uFF09",
        onChange: this.handleSearchChange
      }), loadingFields ? React.createElement("div", {
        style: {
          color: '#999',
          padding: '6px 4px'
        }
      }, "\u52A0\u8F7D\u4E2D...") : filteredFields.length === 0 ? React.createElement("div", {
        style: {
          color: '#999',
          padding: '6px 4px'
        }
      }, "\u65E0\u5339\u914D\u5B57\u6BB5") : React.createElement(Table, {
        columns: columns,
        dataSource: filteredFields,
        rowKey: "fieldName",
        size: "small",
        pagination: false,
        rowSelection: rowSelection,
        style: {
          width: '100%'
        },
        scroll: {
          y: 200
        }
      })));
    }
  }]);

  return FormFieldSelector;
}(React.Component);

ecodeSDK.exp(FormFieldSelector);
ecodeSDK.setCom('${appId}', 'FormFieldSelector', FormFieldSelector);
