"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _ecCom = ecCom,
    WeaRightMenu = _ecCom.WeaRightMenu;
var _antd = antd,
    Button = _antd.Button;
var ActionParamTable = ecodeSDK.imp(ActionParamTable);
/**
 * 流程 Action 配置表单组件，添加高级 Action 参数配置表格
 * @author yaolilin
 */

var NewWeaRightMenu =
/*#__PURE__*/
function (_React$Component) {
  _inherits(NewWeaRightMenu, _React$Component);

  function NewWeaRightMenu(props) {
    var _this;

    _classCallCheck(this, NewWeaRightMenu);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(NewWeaRightMenu).call(this, props));
    _this.state = {
      paramData: []
    };
    return _this;
  }

  _createClass(NewWeaRightMenu, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      // 初始化全局存储对象
      if (!window.workflowActionConfigStore) {
        window.workflowActionConfigStore = {
          actionId: null,
          workflowActionParamMenuInstance: null
        };
      } // 将组件实例存储到全局变量


      window.workflowActionConfigStore.workflowActionParamMenuInstance = this;
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      // 清理全局变量
      if (window.workflowActionConfigStore && window.workflowActionConfigStore.workflowActionParamMenuInstance === this) {
        window.workflowActionConfigStore.workflowActionParamMenuInstance = null;
      }
    }
    /**
     * 获取参数数据
     */

  }, {
    key: "getParamData",
    value: function getParamData() {
      return this.state.paramData;
    }
  }, {
    key: "getAdvancedParamContent",
    value: function getAdvancedParamContent() {
      var _this2 = this;

      var paramData = this.state.paramData;
      return React.createElement("div", {
        style: {
          padding: '0 25px'
        }
      }, React.createElement("p", {
        style: {
          paddingBottom: 10
        }
      }, "\u9AD8\u7EA7\u53C2\u6570\u914D\u7F6E"), React.createElement(ActionParamTable, {
        data: paramData,
        onChange: function onChange(newData) {
          return _this2.setState({
            paramData: newData
          });
        },
        dataSource: this.props.dataSource,
        workflowId: this.props.workflowId,
        modeId: this.props.modeId,
        actionPath: this.props.actionPath
      }));
    }
  }, {
    key: "render",
    value: function render() {
      var children = [];

      if (this.props.children && this.props.children.length > 0) {
        children.push(this.props.children[0]);
        children.push(this.getAdvancedParamContent());
        children.push(this.props.children.slice(1));
      }

      return React.createElement(WeaRightMenu, _extends({}, this.props, {
        children: children,
        _noOverwrite: true
      }));
    }
  }]);

  return NewWeaRightMenu;
}(React.Component);

ecodeSDK.setCom('${appId}', 'NewWeaRightMenu', NewWeaRightMenu);
