"use strict";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function getWorkflowIdFromUrl() {
  var hash = window.location.hash || '';
  var workflowId = null;

  if (hash) {
    var hashIndex = hash.indexOf('?');

    if (hashIndex !== -1) {
      var hashQuery = hash.substring(hashIndex + 1);
      var hashParams = new URLSearchParams(hashQuery);
      workflowId = hashParams.get('workflowId');
    }
  }

  if (!workflowId) {
    var search = window.location.search || '';

    if (search) {
      var params = new URLSearchParams(search);
      workflowId = params.get('workflowId');
    }
  }

  if (!workflowId) {
    return null;
  }

  var id = parseInt(workflowId, 10);
  return isNaN(id) ? null : id;
}

ecodeSDK.overwriteClassFnQueueMapSet('WeaRightMenu', {
  fn: function fn(Com, props) {
    if (props.ecId && props.ecId.includes('WeaRightMenu@s7resx') && !props._noOverwrite) {
      var workflowId = getWorkflowIdFromUrl();
      var actionPath = window.workflowActionConfigStore ? window.workflowActionConfigStore.actionPath : null;
      return {
        com: NewWeaRightMenu,
        props: _objectSpread({}, props, {
          workflowId: workflowId,
          actionPath: actionPath
        })
      };
    }
  }
}); // 创建全局存储对象

if (!window.workflowActionConfigStore) {
  window.workflowActionConfigStore = {
    actionId: null,
    actionPath: null,
    workflowActionParamMenuInstance: null,
    onActionIdChange: null,
    onActionPathChange: null
  };
}
/**
 * 获取 Action 配置对话框中的接口动作标识
 */


ecodeSDK.overwritePropsFnQueueMapSet('Input', {
  fn: function fn(props) {
    if (props.ecId && props.ecId.includes('@integrationWorkflowRegisterCustomFormactionname_InputItem@ujzpqo_WeaInput@bhq4j0')) {
      if (window.workflowActionConfigStore.onActionIdChange) {
        window.workflowActionConfigStore.onActionIdChange(props.value);
        window.workflowActionConfigStore.actionId = props.value;
      }
    }
  }
});
/**
 * 获取 Action 配置对话框中的接口动作类文件输入框参数，获取到 Action 路径
 */

ecodeSDK.overwritePropsFnQueueMapSet('Input', {
  fn: function fn(props) {
    if (props.ecId && props.ecId.includes('integrationWorkflowRegisterCustomFormclassname_InputItem')) {
      if (window.workflowActionConfigStore) {
        if (window.workflowActionConfigStore.actionPath !== props.value) {
          window.workflowActionConfigStore.actionPath = props.value;

          if (window.workflowActionConfigStore.onActionPathChange) {
            window.workflowActionConfigStore.onActionPathChange(props.value);
          }
        }
      }
    }
  }
});
/**
 * 将前端数据转换为后端结构
 * 前端格式：{ name, showName, type (int), required (boolean), assignment (前端格式), detailTable (int), children }
 * 后端格式：{ name, showName, type (枚举), required (boolean), assignment (后端结构), detailTable (int), children }
 */

function convertFrontendDataToBackend(data, parentId) {
  if (!data || !Array.isArray(data)) {
    return [];
  }

  return data.map(function (item) {
    var parsedId = item.id !== undefined && item.id !== null ? parseInt(item.id, 10) : null;
    var currentId = Number.isNaN(parsedId) ? null : parsedId;
    var parsedParentId = parentId !== undefined && parentId !== null ? parseInt(parentId, 10) : null;
    var currentParentId = Number.isNaN(parsedParentId) ? null : parsedParentId;
    var converted = {
      id: currentId,
      parentId: currentParentId,
      name: item.name || '',
      showName: item.showName || '',
      type: item.type !== undefined ? typeof item.type === 'number' ? item.type : item.type.value || item.type : 0,
      required: item.required !== undefined ? item.required === true || item.required === 1 : false,
      detailTable: item.detailTable !== undefined && item.detailTable !== null ? item.detailTable : null,
      assignment: item.assignment
    }; // 递归处理 children

    if (Array.isArray(item.children)) {
      converted.children = convertFrontendDataToBackend(item.children, currentId);
    }

    return converted;
  });
}

function getParamTypeValue(type) {
  if (type === null || type === undefined) {
    return 0;
  }

  if (typeof type === 'number') {
    return type;
  }

  if (_typeof(type) === 'object' && type.value !== undefined) {
    return type.value;
  }

  return type;
}

function hasAssignmentValue(assignment) {
  if (!assignment || assignment.method === undefined || assignment.method === null || !assignment.value) {
    return false;
  }

  if (assignment.method === 1) {
    return assignment.value.workflowField && assignment.value.workflowField.fieldName;
  }

  if (assignment.method === 2 || assignment.method === 3) {
    return assignment.value.value !== undefined && assignment.value.value !== null && assignment.value.value !== '';
  }
}

function validateParamLevel(params) {
  if (!params || !Array.isArray(params)) {
    return null;
  }

  var nameMap = {};

  for (var i = 0; i < params.length; i++) {
    var param = params[i];
    var name = (param.name || '').trim();

    if (!name) {
      return '参数名称不能为空';
    }

    if (nameMap[name]) {
      return '同一层级参数名称重复：' + name;
    }

    nameMap[name] = true;
    var typeValue = getParamTypeValue(param.type);
    var isContainer = typeValue === 3 || typeValue === 4;

    if (param.required && !isContainer && !hasAssignmentValue(param.assignment)) {
      return '必需参数必须选择赋值：' + name;
    }

    if (param.children && param.children.length > 0) {
      var childError = validateParamLevel(param.children);

      if (childError) {
        return childError;
      }
    }
  }

  return null;
}

ecodeSDK.overwritePropsFnQueueMapSet('Button', {
  fn: function fn(props) {
    if (props.ecId && props.ecId.includes('Button@7p1v0n@integrationWorkflowRegisterCustomButtonBTN_SAVE')) {
      var originalOnClick = props.onClick;
      return _objectSpread({}, props, {
        onClick: function onClick() {
          // 检查 actionId 是否存在
          var actionId = window.workflowActionConfigStore.actionId;

          if (!actionId) {
            antd.message.error('请先输入Action标识');
            return;
          } // 获取组件实例


          var menuInstance = window.workflowActionConfigStore.workflowActionParamMenuInstance;

          if (!menuInstance) {
            antd.message.error('无法获取参数配置数据');
            return;
          } // 获取参数数据


          var paramData = menuInstance.getParamData();

          if (!paramData || paramData.length === 0) {
            originalOnClick();
            return;
          }

          var validationError = validateParamLevel(paramData);

          if (validationError) {
            antd.message.error(validationError);
            return;
          } // 将前端数据转换为后端结构


          var convertedData = convertFrontendDataToBackend(paramData); // 调用保存接口

          var url = '/api/second-dev/extend/workflow-action-param/config';
          var loadingMsg = antd.message.loading('正在保存配置...', 0);
          fetch(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              actionId: actionId,
              configs: convertedData
            })
          }).then(function (response) {
            return response.json();
          }).then(function (result) {
            loadingMsg();

            if (!result || !result.success) {
              var errorMsg = result && result.message ? result.message : '未知错误';
              antd.message.error('保存高级 Action 参数失败：' + errorMsg, 5);
              return;
            }

            originalOnClick();
          }).catch(function (error) {
            loadingMsg();
            console.error('保存配置失败:', error);
            antd.message.error('保存高级 Action 参数失败：' + (error.message || '未知错误'), 5);
          });
        }
      });
    }
  }
});

var NewWeaRightMenu = function NewWeaRightMenu(props) {
  var params = {
    appId: '${appId}',
    name: 'NewWeaRightMenu',
    isPage: false,
    noCss: true,
    props: props
  };
  var NewCom = props.Com;
  return window.comsMobx ? ecodeSDK.getAsyncCom(params) : React.createElement(NewCom, props);
};