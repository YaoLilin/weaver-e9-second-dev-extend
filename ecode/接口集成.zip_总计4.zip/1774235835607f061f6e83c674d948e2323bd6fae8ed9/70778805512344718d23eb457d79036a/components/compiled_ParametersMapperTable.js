"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Input = _antd.Input,
    Select = _antd.Select,
    Button = _antd.Button,
    message = _antd.message;
var _ecCom = ecCom,
    WeaHelpfulTip = _ecCom.WeaHelpfulTip;
var Option = Select.Option;
var JsonParametersTable = ecodeSDK.imp(JsonParametersTable);
var COMMON_COMPONENT_APP_ID = '812a0239c1e7469eb27e635cb619a2cb';
var PropTypes = window.PropTypes;
/**
 * props: {
 *     formId?: 1,
 *     workflowId?: 1,  // 流程ID
 *     modeId?: 1,  // 建模ID（可选，如果未传入则从 URL 获取）
 *     dataSource?: 'workflow' | 'mode',  // 字段来源
 *     data: [],
 *     onChange: (data) => {},
 * }
 * 支持配置 JSON 参数结构，并支持字段映射（赋值方式/取值）。
 */

var ParametersMapperTable =
/*#__PURE__*/
function (_React$Component) {
  _inherits(ParametersMapperTable, _React$Component);

  function ParametersMapperTable(props) {
    var _this;

    _classCallCheck(this, ParametersMapperTable);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ParametersMapperTable).call(this, props));

    _this.generateParamId = function () {
      var maxInt = 2147483647;
      var base = Date.now() % maxInt;
      var rand = Math.floor(Math.random() * 1000);
      var id = base + rand;
      return (id >= maxInt ? base : id).toString();
    };

    _this.buildAssignmentValue = function (assignment) {
      if (!assignment) {
        return {
          method: 1,
          value: {
            workflowField: {},
            value: ''
          }
        };
      }

      var method = assignment.method;
      var value = assignment.value || {};

      if (method === 1 || method === 2 || method === 3) {
        return assignment;
      }

      var methodMap = {
        FORM_FIELD: 1,
        SYSTEM_PARAM: 2,
        FIXED_VALUE: 3
      };
      return {
        method: methodMap[method] || 1,
        value: {
          workflowField: value.workflowField || {},
          value: value.value || ''
        }
      };
    };

    _this.buildAssignmentData = function () {
      var _this$state = _this.state,
          formFieldsByCategory = _this$state.formFieldsByCategory,
          systemParams = _this$state.systemParams;
      var mainFields = formFieldsByCategory.MAIN || [];
      var details = Object.keys(formFieldsByCategory).filter(function (key) {
        return key.indexOf('DT') === 0;
      }).map(function (key) {
        var num = parseInt(key.substring(2), 10);
        return {
          detailNum: num,
          fields: formFieldsByCategory[key] || []
        };
      }).filter(function (item) {
        return !isNaN(item.detailNum);
      });
      return {
        formFields: {
          mainFields: mainFields,
          details: details
        },
        systemParams: systemParams || []
      };
    };

    _this.state = {
      JsonParametersTable: null,
      AssignmentCell: null,
      // 字段数据相关
      formFieldCategories: [],
      formFieldsByCategory: {},
      loadingFields: false,
      detailTableOptions: [],
      systemParams: []
    };
    return _this;
  }

  _createClass(ParametersMapperTable, [{
    key: "loadWorkflowFields",

    /**
     * 调用接口获取流程字段信息
     */
    value: async function loadWorkflowFields(workflowId) {
      if (!workflowId || workflowId <= 0) {
        return;
      }

      this.setState({
        loadingFields: true
      });

      try {
        var response = await fetch('/api/second-dev/extend/workflow/fields?workflowId=' + workflowId, {
          method: 'GET'
        });
        var result = await response.json();

        if (result.success && result.data) {
          var fields = result.data; // 根据 detailTable 字段分类

          this.categorizeFields(fields);
        } else {
          message.error('获取流程字段失败：' + (result.message || '未知错误'));
        }
      } catch (error) {
        message.error('获取流程字段失败：' + error.message);
      } finally {
        this.setState({
          loadingFields: false
        });
      }
    }
    /**
     * 调用接口获取建模字段信息
     */

  }, {
    key: "loadModeFields",
    value: async function loadModeFields(modeId) {
      if (!modeId || modeId <= 0) {
        return;
      }

      this.setState({
        loadingFields: true
      });

      try {
        var response = await fetch('/api/second-dev/extend/modes/fields?modeId=' + modeId, {
          method: 'GET'
        });
        var result = await response.json();

        if (result.success && result.data) {
          var fields = result.data;
          this.categorizeFields(fields);
        } else {
          message.error('获取建模字段失败：' + (result.message || '未知错误'));
        }
      } catch (error) {
        message.error('获取建模字段失败：' + error.message);
      } finally {
        this.setState({
          loadingFields: false
        });
      }
    }
    /**
     * 调用接口获取系统参数列表
     */

  }, {
    key: "loadSystemParams",
    value: async function loadSystemParams() {
      try {
        var response = await fetch('/api/second-dev/extend/workflow-action-param/system-params', {
          method: 'GET'
        });
        var result = await response.json();

        if (result.success && result.data) {
          this.setState({
            systemParams: result.data
          });
        }
      } catch (error) {
        console.error('获取系统参数失败:', error);
      }
    }
    /**
     * 根据后端返回的数据结构对流程字段进行分类
     * 后端返回：{ mainFields: [], details: [{ detailNum: 1, fields: [] }, ...] }
     */

  }, {
    key: "categorizeFields",
    value: function categorizeFields(data) {
      var categories = [];
      var fieldsByCategory = {};
      var detailTableOptions = []; // 主表字段

      if (data.mainFields && data.mainFields.length > 0) {
        categories.push({
          value: 'MAIN',
          label: '主表字段'
        });
        fieldsByCategory['MAIN'] = data.mainFields.map(function (f) {
          return {
            id: f.fieldName,
            name: f.labelName,
            fieldName: f.fieldName,
            labelName: f.labelName,
            fieldType: f.fieldType
          };
        });
      } // 明细表字段


      if (data.details && data.details.length > 0) {
        data.details.forEach(function (detail) {
          if (detail.detailNum && detail.fields && detail.fields.length > 0) {
            var categoryValue = 'DT' + detail.detailNum;
            categories.push({
              value: categoryValue,
              label: '明细表' + detail.detailNum
            });
            fieldsByCategory[categoryValue] = detail.fields.map(function (f) {
              return {
                id: f.fieldName,
                name: f.labelName,
                fieldName: f.fieldName,
                labelName: f.labelName,
                fieldType: f.fieldType,
                detailTableNum: detail.detailNum
              };
            }); // 生成明细表选项

            detailTableOptions.push({
              value: detail.detailNum,
              label: '明细表' + detail.detailNum
            });
          }
        });
      }

      this.setState({
        formFieldCategories: categories,
        formFieldsByCategory: fieldsByCategory,
        detailTableOptions: detailTableOptions
      });
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      ecodeSDK.load({
        id: '494a669f59304c6dae317a190d8159a3',
        cb: function cb() {
          _this2.setState({
            JsonParametersTable: ecodeSDK.getCom('494a669f59304c6dae317a190d8159a3', 'JsonParametersTable')
          });
        }
      });

      if (COMMON_COMPONENT_APP_ID) {
        ecodeSDK.load({
          id: COMMON_COMPONENT_APP_ID,
          cb: function cb() {
            _this2.setState({
              AssignmentCell: ecodeSDK.getCom(COMMON_COMPONENT_APP_ID, 'AssignmentCell')
            });
          }
        });
      }

      var dataSource = this.props.dataSource;

      if (dataSource === 'mode') {
        var modeId = this.props.modeId;

        if (modeId && modeId > 0) {
          this.loadModeFields(modeId);
        }
      } else {
        var workflowId = this.props.workflowId;

        if (workflowId && workflowId > 0) {
          this.loadWorkflowFields(workflowId);
        }
      } // 加载系统参数


      this.loadSystemParams();
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var _this$props = this.props,
          data = _this$props.data,
          onChange = _this$props.onChange;
      var _this$state2 = this.state,
          JsonParametersTable = _this$state2.JsonParametersTable,
          AssignmentCell = _this$state2.AssignmentCell,
          loadingFields = _this$state2.loadingFields;
      return React.createElement("div", null, JsonParametersTable ? React.createElement(JsonParametersTable, {
        data: data,
        onChange: onChange,
        readonly: true,
        resetFieldValuesOnTypeChange: {
          assignment: null,
          detailTable: ''
        },
        extendColumns: function extendColumns(_ref) {
          var handleChange = _ref.handleChange;
          return [{
            title: '说明',
            dataIndex: 'desc',
            key: 'desc',
            width: 50,
            render: function render(text) {
              if (!text) {
                return null;
              }

              return React.createElement(WeaHelpfulTip, {
                title: text,
                placement: "top",
                width: 260
              });
            }
          }, {
            title: '赋值',
            dataIndex: 'assignment',
            key: 'assignment',
            width: 250,
            render: function render(text, record) {
              if (!AssignmentCell) {
                return null;
              }

              return React.createElement(AssignmentCell, {
                record: record,
                value: _this3.buildAssignmentValue(record.assignment),
                data: _this3.buildAssignmentData(),
                loadingFields: loadingFields,
                onChangeAssignment: handleChange
              });
            }
          }, {
            title: React.createElement("span", {
              style: {
                display: 'inline-flex',
                alignItems: 'center'
              }
            }, "\u660E\u7EC6\u8868", React.createElement("span", {
              style: {
                marginLeft: 4
              }
            }, React.createElement(WeaHelpfulTip, {
              title: "\u5982\u679C\u6570\u7EC4\u7C7B\u578B\u53C2\u6570\u7684\u5B50\u53C2\u6570\u9700\u8981\u83B7\u53D6\u660E\u7EC6\u8868\u5B57\u6BB5\uFF0C\u5219\u8BE5\u6570\u7EC4\u53C2\u6570\u9700\u8981\u9009\u62E9\u660E\u7EC6\u8868",
              placement: "top",
              width: 260
            }))),
            dataIndex: 'detailTable',
            key: 'detailTable',
            render: function render(text, record) {
              // 仅当参数类型为数组(4)时显示
              if (record.type !== 4) {
                return null;
              }

              return React.createElement(Select, {
                style: {
                  width: 100
                },
                value: text || undefined,
                placeholder: "\u8BF7\u9009\u62E9",
                allowClear: true,
                onChange: function onChange(v) {
                  return handleChange(record.id, 'detailTable', v || null);
                }
              }, _this3.state.detailTableOptions.map(function (o) {
                return React.createElement(Option, {
                  key: o.value,
                  value: o.value
                }, o.label);
              }));
            }
          }];
        }
      }) : null);
    }
  }]);

  return ParametersMapperTable;
}(React.Component);

ParametersMapperTable.defaultProps = {
  formId: null,
  workflowId: null,
  modeId: null,
  dataSource: 'workflow',
  data: [],
  onChange: null
};

if (PropTypes) {
  ParametersMapperTable.propTypes = {
    /** 表单ID */
    formId: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),

    /** 流程ID */
    workflowId: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),

    /** 建模ID */
    modeId: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),

    /** 字段来源 */
    dataSource: PropTypes.oneOf(['workflow', 'mode']),

    /** 参数数据 */
    data: PropTypes.array,

    /** 数据变更回调 */
    onChange: PropTypes.func
  };
}

ecodeSDK.exp(ParametersMapperTable);
ecodeSDK.setCom('${appId}', 'ParametersMapperTable', ParametersMapperTable);