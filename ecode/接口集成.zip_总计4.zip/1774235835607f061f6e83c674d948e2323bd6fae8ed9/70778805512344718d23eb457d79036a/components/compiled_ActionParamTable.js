"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    message = _antd.message;
var COMMON_COMPONENT_APP_ID = '812a0239c1e7469eb27e635cb619a2cb';
var PropTypes = window.PropTypes;
/**
 * Action 参数配置表格
 * props: {
 *     workflowId?: number | string,  // 流程ID
 *     data: [],
 *     onChange: (data) => {},
 *     actionPath?: string,
 * }
 */

var ActionParamTable =
/*#__PURE__*/
function (_React$Component) {
  _inherits(ActionParamTable, _React$Component);

  function ActionParamTable(props) {
    var _this;

    _classCallCheck(this, ActionParamTable);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ActionParamTable).call(this, props));

    _this.getActionPath = function () {
      var actionPath = _this.props.actionPath || (window.workflowActionConfigStore ? window.workflowActionConfigStore.actionPath : null);
      return actionPath || '';
    };

    _this.generateParamId = function () {
      var maxInt = 2147483647;
      var base = Date.now() % maxInt;
      var rand = Math.floor(Math.random() * 1000);
      var id = base + rand;
      return (id >= maxInt ? base : id).toString();
    };

    _this.convertBackendDataToFrontend = function (backendData, isRootLevel) {
      if (!backendData || !Array.isArray(backendData)) {
        return [];
      }

      return backendData.map(function (item) {
        var converted = {
          id: item.id ? item.id.toString() : _this.generateParamId(),
          name: item.name || '',
          showName: item.showName || '',
          type: item.type !== undefined ? _typeof(item.type) === 'object' ? item.type.value : item.type : 0,
          required: item.required !== undefined ? item.required === true || item.required === 1 : false,
          assignment: item.assignment,
          detailTable: item.detailTable !== undefined && item.detailTable !== null ? item.detailTable : null,
          desc: item.desc || ''
        };

        if (isRootLevel && converted.name === 'actionId' && _this.actionId) {
          converted.assignment = {
            method: 3,
            value: {
              value: _this.actionId
            }
          };
        }

        if (item.children && Array.isArray(item.children) && item.children.length > 0) {
          converted.children = _this.convertBackendDataToFrontend(item.children, false);
        }

        return converted;
      });
    };

    _this.actionId = null;
    _this.actionPath = null;
    _this.state = {
      ParametersMapperTable: null
    };
    return _this;
  }

  _createClass(ActionParamTable, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      if (COMMON_COMPONENT_APP_ID) {
        ecodeSDK.load({
          id: COMMON_COMPONENT_APP_ID,
          cb: function cb() {
            _this2.setState({
              ParametersMapperTable: ecodeSDK.getCom(COMMON_COMPONENT_APP_ID, 'ParametersMapperTable')
            });
          }
        });
      }

      if (!window.workflowActionConfigStore) {
        return;
      }

      window.workflowActionConfigStore.onActionIdChange = function (actionId) {
        if (_this2.actionId !== actionId) {
          _this2.actionId = actionId;

          _this2.fetchAdvanceParams();
        }
      };

      window.workflowActionConfigStore.onActionPathChange = function (actionPath) {
        if (_this2.actionPath !== actionPath) {
          _this2.actionPath = actionPath;

          _this2.fetchAdvanceParams();
        }
      };

      this.fetchAdvanceParams();
    }
  }, {
    key: "fetchAdvanceParams",
    value: async function fetchAdvanceParams() {
      var actionId = this.actionId;
      var workflowId = this.props.workflowId;
      var actionPath = this.getActionPath();

      if (!actionId || !workflowId || !actionPath) {
        return;
      }

      try {
        var url = '/api/second-dev/extend/workflow-action-param/config?actionId=' + encodeURIComponent(actionId);

        if (workflowId) {
          url += '&workflowId=' + workflowId;
        }

        if (actionPath) {
          url += '&actionPath=' + encodeURIComponent(actionPath);
        }

        var response = await fetch(url, {
          method: 'GET'
        });
        var result = await response.json();

        if (result.success && result.data) {
          var convertedData = this.convertBackendDataToFrontend(result.data, true);

          if (this.props.onChange && convertedData && convertedData.length > 0) {
            this.props.onChange(convertedData);
          } else if (this.props.onChange) {
            this.props.onChange([]);
          }
        } else if (!result.success) {
          message.error('获取高级 Action 参数配置失败：' + (result.message || '未知错误'));
        }
      } catch (error) {
        console.error('获取高级 Action 参数配置失败:', error);
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$props = this.props,
          data = _this$props.data,
          onChange = _this$props.onChange,
          workflowId = _this$props.workflowId;
      var ParametersMapperTable = this.state.ParametersMapperTable;

      if (!ParametersMapperTable) {
        return null;
      }

      return React.createElement(ParametersMapperTable, {
        workflowId: workflowId,
        data: data,
        onChange: onChange
      });
    }
  }]);

  return ActionParamTable;
}(React.Component);

ActionParamTable.defaultProps = {
  workflowId: null,
  data: [],
  onChange: null,
  actionPath: ''
};

if (PropTypes) {
  ActionParamTable.propTypes = {
    /** 流程ID */
    workflowId: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),

    /** 参数数据 */
    data: PropTypes.array,

    /** 数据变更回调 */
    onChange: PropTypes.func,

    /** Action 路径 */
    actionPath: PropTypes.string
  };
}

ecodeSDK.exp(ActionParamTable);
ecodeSDK.setCom('${appId}', 'ActionParamTable', ActionParamTable);