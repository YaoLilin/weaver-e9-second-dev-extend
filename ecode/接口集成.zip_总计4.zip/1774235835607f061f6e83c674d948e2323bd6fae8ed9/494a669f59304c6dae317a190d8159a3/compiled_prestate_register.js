"use strict";

// 访问地址：/spa/custom/static/index.html#/main/cs/app/494a669f59304c6dae317a190d8159a3_ApiList
ecodeSDK.rewriteRouteQueue.push({
  fn: function fn(params) {
    var Com = params.Com,
        Route = params.Route,
        nextState = params.nextState;
    var cpParams = {
      path: 'main/cs/app',
      //路由地址
      appId: '${appId}',
      name: 'ApiList',
      //具体页面应用id
      node: 'app',
      //渲染的路由节点，这里渲染的是app这个节点
      Route: Route,
      nextState: nextState
    };

    if (ecodeSDK.checkPath(cpParams)) {
      //判断地址是否是要注入的地址
      var acParams = {
        appId: cpParams.appId,
        name: cpParams.name,
        //模块名称
        props: params,
        //参数
        isPage: true //是否是路由页面
        //异步加载模块${appId}下的子模块pageSimple

      };
      return ecodeSDK.getAsyncCom(acParams);
    }

    return null; //这里一定要返回空，不然会干扰到其它新页面
  },
  order: 10,
  desc: '接口配置列表'
}); // 访问地址：/spa/custom/static/index.html#/main/cs/app/494a669f59304c6dae317a190d8159a3_MappingConfList

ecodeSDK.rewriteRouteQueue.push({
  fn: function fn(params) {
    var Com = params.Com,
        Route = params.Route,
        nextState = params.nextState;
    var cpParams = {
      path: 'main/cs/app',
      //路由地址
      appId: '${appId}',
      name: 'MappingConfList',
      //具体页面应用id
      node: 'app',
      //渲染的路由节点，这里渲染的是app这个节点
      Route: Route,
      nextState: nextState
    };

    if (ecodeSDK.checkPath(cpParams)) {
      //判断地址是否是要注入的地址
      var acParams = {
        appId: cpParams.appId,
        name: cpParams.name,
        //模块名称
        props: params,
        //参数
        isPage: true //是否是路由页面
        //异步加载模块${appId}下的子模块pageSimple

      };
      return ecodeSDK.getAsyncCom(acParams);
    }

    return null; //这里一定要返回空，不然会干扰到其它新页面
  },
  order: 10,
  desc: '接口映射配置列表'
});