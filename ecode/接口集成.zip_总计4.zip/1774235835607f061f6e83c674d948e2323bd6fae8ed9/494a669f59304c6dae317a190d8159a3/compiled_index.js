"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Table = _antd.Table,
    Button = _antd.Button,
    message = _antd.message;
var _ecCom = ecCom,
    WeaTools = _ecCom.WeaTools;
var callApi = WeaTools.callApi;
var ApiConfDialog = ecodeSDK.imp(ApiConfDialog);

var ApiList =
/*#__PURE__*/
function (_React$Component) {
  _inherits(ApiList, _React$Component);

  function ApiList(props) {
    var _this;

    _classCallCheck(this, ApiList);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ApiList).call(this, props));

    _this.cleanInterfaceData = function () {
      _this.setState({
        interfaceData: {
          bodyParameters: [],
          queryParameters: [],
          headerParameters: [],
          returnParameters: [],
          formData: {
            url: '',
            method: 0,
            apiId: '',
            name: '',
            bodyType: 0,
            bodyDetailNum: null
          }
        }
      });
    };

    _this.loadInterfaceList = function (pageNo, pageSize) {
      var query = '?pageNo=' + pageNo + '&pageSize=' + pageSize;
      callApi('/api/second-dev/extend/apis' + query, 'GET').then(function (result) {
        var list = result && result.list ? result.list : Array.isArray(result) ? result : [];
        var total = result && result.total !== undefined ? result.total : list.length;
        var currentPage = result && result.pageNo ? result.pageNo : pageNo;
        var currentSize = result && result.pageSize ? result.pageSize : pageSize;

        _this.setState({
          data: list,
          total: total,
          pageNo: currentPage,
          pageSize: currentSize
        });
      }).catch(function (e) {
        message.error('获取列表失败');
      });
    };

    _this.handleClickName = function (id) {
      callApi('/api/second-dev/extend/apis/' + id, 'GET').then(function (result) {
        var interfaceData = {
          formData: {
            url: result.url,
            method: result.method,
            apiId: result.apiId,
            name: result.name,
            bodyType: result.bodyType !== undefined && result.bodyType !== null ? result.bodyType : 0,
            bodyDetailNum: result.bodyDetailNum !== undefined ? result.bodyDetailNum : null
          },
          bodyParameters: result.bodyParameters,
          queryParameters: result.queryParameters,
          headerParameters: result.headerParameters,
          returnParameters: result.returnParameters
        };

        _this.setState({
          interfaceData: interfaceData,
          dialogVisible: true,
          isCreate: false
        });
      }).catch(function (e) {
        message.error('获取接口信息失败');
      });
    };

    _this.handleDialogChange = function (newData) {
      _this.setState({
        interfaceData: newData
      });
    };

    _this.columns = [{
      title: '接口名称',
      dataIndex: 'name',
      render: function render(text, data) {
        return React.createElement("span", {
          style: {
            color: 'rgb(77, 122, 216)',
            cursor: 'pointer'
          },
          onClick: function onClick() {
            return _this.handleClickName(data.id);
          }
        }, text);
      }
    }, {
      title: '接口地址',
      dataIndex: 'url'
    }, {
      title: '请求方法',
      dataIndex: 'method'
    }];
    _this.state = {
      data: [],
      total: 0,
      pageNo: 1,
      pageSize: 10,
      dialogVisible: false,
      interfaceData: {
        bodyParameters: [],
        queryParameters: [],
        headerParameters: [],
        returnParameters: [],
        formData: {
          url: '',
          method: 0,
          apiId: '',
          name: '',
          bodyType: 0,
          bodyDetailNum: null
        }
      },
      isCreate: false
    };
    return _this;
  }

  _createClass(ApiList, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.loadInterfaceList(1, this.state.pageSize);
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var _this$state = this.state,
          data = _this$state.data,
          dialogVisible = _this$state.dialogVisible,
          interfaceData = _this$state.interfaceData,
          isCreate = _this$state.isCreate,
          total = _this$state.total,
          pageNo = _this$state.pageNo,
          pageSize = _this$state.pageSize;
      return React.createElement("div", {
        style: {
          padding: 20
        }
      }, React.createElement("div", {
        style: {
          marginBottom: 10,
          textAlign: 'right'
        }
      }, React.createElement(Button, {
        type: 'primary',
        onClick: function onClick() {
          _this2.cleanInterfaceData();

          _this2.setState({
            dialogVisible: true,
            isCreate: true
          });
        }
      }, "\u6DFB\u52A0")), React.createElement(Table, {
        columns: this.columns,
        dataSource: data,
        pagination: {
          current: pageNo,
          pageSize: pageSize,
          total: total,
          showSizeChanger: true,
          onChange: function onChange(page, size) {
            return _this2.loadInterfaceList(page, size);
          },
          onShowSizeChange: function onShowSizeChange(page, size) {
            return _this2.loadInterfaceList(page, size);
          }
        }
      }), React.createElement(ApiConfDialog, {
        visible: dialogVisible,
        data: interfaceData,
        isCreate: isCreate,
        onChange: this.handleDialogChange,
        onOk: function onOk() {
          return _this2.setState({
            dialogVisible: false
          });
        },
        onCancel: function onCancel() {
          return _this2.setState({
            dialogVisible: false
          });
        }
      }));
    }
  }]);

  return ApiList;
}(React.Component);

ecodeSDK.setCom('${appId}', 'ApiList', ApiList);