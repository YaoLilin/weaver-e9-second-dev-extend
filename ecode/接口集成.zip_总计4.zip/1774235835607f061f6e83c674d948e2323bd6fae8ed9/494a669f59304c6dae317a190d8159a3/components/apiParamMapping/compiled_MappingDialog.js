"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Modal = _antd.Modal,
    message = _antd.message;
var _ecCom = ecCom,
    WeaTools = _ecCom.WeaTools;
var callApi = WeaTools.callApi;
var MappingConfig = ecodeSDK.imp(MappingConfig);

var MappingDialog =
/*#__PURE__*/
function (_React$Component) {
  _inherits(MappingDialog, _React$Component);

  function MappingDialog(props) {
    var _this;

    _classCallCheck(this, MappingDialog);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(MappingDialog).call(this, props));

    _this.handleOk = function () {
      var _this$props = _this.props,
          data = _this$props.data,
          onOk = _this$props.onOk;

      var payload = _this.buildSavePayload(data);

      if (!payload) {
        return;
      }

      var url = '/api/second-dev/extend/apis/mapping';
      var loading = message.loading('正在保存配置...', 0);
      fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      }).then(function (res) {
        return res.json();
      }).then(function (result) {
        loading();

        if (!result || !result.success) {
          message.error('保存配置失败：' + (result && result.message || '未知错误'));
          return;
        }

        if (onOk) {
          onOk();
        }
      }).catch(function (error) {
        loading();
        message.error('保存配置失败：' + (error.message || '未知错误'));
      });
    };

    _this.handleCancel = function () {
      _this.props.onCancel();
    };

    _this.handleChange = function (newData) {
      var onChange = _this.props.onChange;
      onChange(newData);
    };

    _this.buildSavePayload = function (data) {
      if (!data) {
        message.error('配置数据不能为空');
        return null;
      }

      var mappingData = data.mappingData || {};
      var apiId = data.api && data.api.id ? data.api.id : null;

      if (!apiId) {
        message.error('请选择接口');
        return null;
      }

      var dataSource = data.dataSource === 'model' ? 1 : 0;
      return {
        confId: data.confId || '',
        name: data.name || '',
        apiId: apiId,
        dataSource: dataSource,
        workflow: data.workflow && data.workflow.id ? data.workflow.id : null,
        modeId: data.modelInfo && data.modelInfo.id ? data.modelInfo.id : null,
        bodyDetailNum: data.bodyDetailNum || null,
        headerParameters: _this.convertParams(mappingData.headerParameters || []),
        queryParameters: _this.convertParams(mappingData.queryParameters || []),
        bodyParameters: _this.convertParams(mappingData.bodyParameters || [])
      };
    };

    _this.convertParams = function (params) {
      if (!params || !Array.isArray(params)) {
        return [];
      }

      return params.map(function (item) {
        var normalizedAssignment = _this.normalizeAssignment(item.assignment);

        var result = {
          name: item.name || '',
          paramId: item.id || '',
          assignment: normalizedAssignment,
          detailNum: _this.normalizeDetailNum(item.detailNum)
        };

        if (item.children && item.children.length > 0) {
          result.children = _this.convertParams(item.children);
        }

        return result;
      });
    };

    _this.normalizeAssignment = function (assignment) {
      if (!assignment) {
        return null;
      }

      var method = assignment.method;

      if (method === undefined || method === null) {
        return assignment;
      }

      if (method && _typeof(method) === 'object' && method.value !== undefined) {
        method = parseInt(method.value, 10);
        return Object.assign({}, assignment, {
          method: method
        });
      }

      if (typeof method === 'number') {
        return assignment;
      }

      if (typeof method === 'string' && /^d+$/.test(method)) {
        return Object.assign({}, assignment, {
          method: parseInt(method, 10)
        });
      }

      return null;
    };

    _this.normalizeDetailNum = function (detailTable) {
      if (detailTable === undefined || detailTable === null || detailTable === '') {
        return null;
      }

      var value = parseInt(detailTable, 10);
      return isNaN(value) ? null : value;
    };

    return _this;
  }

  _createClass(MappingDialog, [{
    key: "render",
    value: function render() {
      var _this$props2 = this.props,
          visible = _this$props2.visible,
          data = _this$props2.data,
          isCreate = _this$props2.isCreate;
      var footer = [React.createElement(Button, {
        onClick: this.handleCancel
      }, "\u53D6\u6D88"), React.createElement(Button, {
        type: 'primary',
        onClick: this.handleOk
      }, "\u4FDD\u5B58")];
      return React.createElement(Modal, {
        title: "\u63A5\u53E3\u914D\u7F6E",
        width: 1000,
        visible: visible,
        footer: footer,
        maskClosable: false,
        onOk: this.handleOk,
        onCancel: this.handleCancel
      }, React.createElement(MappingConfig, {
        data: data,
        isCreate: isCreate,
        onChange: this.handleChange
      }));
    }
  }]);

  return MappingDialog;
}(React.Component);

ecodeSDK.exp(MappingDialog);