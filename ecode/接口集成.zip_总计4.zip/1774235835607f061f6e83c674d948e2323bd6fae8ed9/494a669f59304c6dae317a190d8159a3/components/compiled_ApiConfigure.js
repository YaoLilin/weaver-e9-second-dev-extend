"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Input = _antd.Input,
    Select = _antd.Select,
    Button = _antd.Button,
    Table = _antd.Table,
    Switch = _antd.Switch,
    Icon = _antd.Icon,
    Tabs = _antd.Tabs;
var TabPane = Tabs.TabPane;
var _ecCom = ecCom,
    WeaFormItem = _ecCom.WeaFormItem;
var Option = Select.Option;
var ParametersTable = ecodeSDK.imp(ParametersTable);
var JsonParametersTable = ecodeSDK.imp(JsonParametersTable);
var ParameterForm = ecodeSDK.imp(ParameterForm);

var ApiConfigure =
/*#__PURE__*/
function (_React$Component) {
  _inherits(ApiConfigure, _React$Component);

  function ApiConfigure(props) {
    var _this;

    _classCallCheck(this, ApiConfigure);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ApiConfigure).call(this, props));

    _this.handleQueryParamChange = function (newData) {
      var _this$props = _this.props,
          onChange = _this$props.onChange,
          data = _this$props.data;

      var newConfData = _objectSpread({}, data);

      newConfData.queryParameters = newData;
      onChange(newConfData);
    };

    _this.handleHeaderParamChange = function (newData) {
      var _this$props2 = _this.props,
          onChange = _this$props2.onChange,
          data = _this$props2.data;

      var newConfData = _objectSpread({}, data);

      newConfData.headerParameters = newData;
      onChange(newConfData);
    };

    _this.handleBodyParamChange = function (newData) {
      var _this$props3 = _this.props,
          onChange = _this$props3.onChange,
          data = _this$props3.data;

      var newConfData = _objectSpread({}, data);

      newConfData.bodyParameters = newData;
      onChange(newConfData);
    };

    _this.handleReturnParamChange = function (newData) {
      var _this$props4 = _this.props,
          onChange = _this$props4.onChange,
          data = _this$props4.data;

      var newConfData = _objectSpread({}, data);

      newConfData.returnParameters = newData;
      onChange(newConfData);
    };

    _this.handleFormDataChange = function (newData) {
      var _this$props5 = _this.props,
          onChange = _this$props5.onChange,
          data = _this$props5.data;

      var newConfData = _objectSpread({}, data);

      newConfData.formData = newData;
      onChange(newConfData);
    };

    _this.handleBodyTypeChange = function (value) {
      var _this$props6 = _this.props,
          onChange = _this$props6.onChange,
          data = _this$props6.data;

      var newConfData = _objectSpread({}, data);

      newConfData.formData = _objectSpread({}, newConfData.formData || {}, {
        bodyType: value
      });
      onChange(newConfData);
    };

    return _this;
  }

  _createClass(ApiConfigure, [{
    key: "render",
    value: function render() {
      var _this$props$data = this.props.data,
          bodyParameters = _this$props$data.bodyParameters,
          queryParameters = _this$props$data.queryParameters,
          headerParameters = _this$props$data.headerParameters,
          returnParameters = _this$props$data.returnParameters,
          formData = _this$props$data.formData;
      var bodyType = formData && formData.bodyType !== undefined && formData.bodyType !== null ? formData.bodyType : 0;
      var onChange = this.props.onChange;
      return React.createElement("div", {
        style: {
          padding: 20,
          height: 700,
          overflow: 'scroll'
        }
      }, React.createElement(ParameterForm, {
        data: formData,
        onChange: this.handleFormDataChange
      }), React.createElement(Tabs, {
        defaultActiveKey: "1"
      }, React.createElement(TabPane, {
        tab: "\u67E5\u8BE2\u53C2\u6570",
        key: "1"
      }, React.createElement(ParametersTable, {
        data: queryParameters,
        onChange: this.handleQueryParamChange
      })), React.createElement(TabPane, {
        tab: "\u8BF7\u6C42\u5934",
        key: "2"
      }, React.createElement(ParametersTable, {
        data: headerParameters,
        onChange: this.handleHeaderParamChange
      })), React.createElement(TabPane, {
        tab: "\u8BF7\u6C42\u4F53",
        key: "3"
      }, React.createElement("div", {
        style: {
          marginBottom: 12
        }
      }, React.createElement("span", {
        style: {
          marginRight: 8
        }
      }, "Body \u7C7B\u578B\uFF1A"), React.createElement(Select, {
        value: bodyType,
        onChange: this.handleBodyTypeChange,
        style: {
          width: 160
        }
      }, React.createElement(Option, {
        value: 0
      }, "\u5BF9\u8C61"), React.createElement(Option, {
        value: 1
      }, "\u6570\u7EC4"))), React.createElement(JsonParametersTable, {
        data: bodyParameters,
        onChange: this.handleBodyParamChange
      })), React.createElement(TabPane, {
        tab: "\u8FD4\u56DE\u53C2\u6570",
        key: "4"
      }, React.createElement(JsonParametersTable, {
        data: returnParameters,
        onChange: this.handleReturnParamChange
      }))));
    }
  }]);

  return ApiConfigure;
}(React.Component);

ecodeSDK.exp(ApiConfigure); // 确保 ecodeSDK.setCom 方法正确调用

ecodeSDK.setCom('${appId}', 'ParameterMapping', ApiConfigure);