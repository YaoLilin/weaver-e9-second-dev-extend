"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Input = _antd.Input,
    Select = _antd.Select,
    Button = _antd.Button,
    Table = _antd.Table,
    Switch = _antd.Switch,
    Icon = _antd.Icon,
    message = _antd.message;
var Option = Select.Option;
var ParamValue = ecodeSDK.imp(ParamValue);
var JsonParametersTable = ecodeSDK.imp(JsonParametersTable);
/**
 * props: {
 *     formId?: 1,
 *     data: [],
 *     onChange: (data) => {},
 * }
 * 支持配置 JSON 参数结构，并支持字段映射（赋值方式/取值）。
 */

var JsonParametersMapperTable =
/*#__PURE__*/
function (_React$Component) {
  _inherits(JsonParametersMapperTable, _React$Component);

  function JsonParametersMapperTable() {
    _classCallCheck(this, JsonParametersMapperTable);

    return _possibleConstructorReturn(this, _getPrototypeOf(JsonParametersMapperTable).apply(this, arguments));
  }

  _createClass(JsonParametersMapperTable, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          data = _this$props.data,
          onChange = _this$props.onChange,
          formId = _this$props.formId,
          readonly = _this$props.readonly;
      return React.createElement(JsonParametersTable, {
        data: data,
        onChange: onChange,
        readonly: readonly,
        resetFieldsOnTypeChange: ['assignmentMethod', 'value'],
        extendColumns: function extendColumns(_ref) {
          var handleChange = _ref.handleChange;
          return [{
            title: '赋值方式',
            dataIndex: 'assignmentMethod',
            key: 'assignmentMethod',
            render: function render(text, record) {
              return record.type !== 3 && record.type !== 4 ? React.createElement(Select, {
                value: text,
                onChange: function onChange(value) {
                  handleChange(record.id, 'value', '');
                  handleChange(record.id, 'assignmentMethod', value);
                },
                style: {
                  width: 120
                },
                disabled: record.type === 3 || record.type === 4
              }, React.createElement(Option, {
                value: 0
              }, "\u8868\u5355\u5B57\u6BB5"), React.createElement(Option, {
                value: 1
              }, "\u7CFB\u7EDF\u53D8\u91CF"), React.createElement(Option, {
                value: 2
              }, "\u56FA\u5B9A\u503C")) : null;
            }
          }, {
            title: '取值',
            dataIndex: 'value',
            key: 'value',
            render: function render(text, record) {
              return React.createElement(ParamValue, {
                type: record.assignmentMethod,
                value: text,
                formId: formId,
                onChange: function onChange(v) {
                  return handleChange(record.id, 'value', v);
                }
              });
            }
          }];
        }
      });
    }
  }]);

  return JsonParametersMapperTable;
}(React.Component);

ecodeSDK.exp(JsonParametersMapperTable);
ecodeSDK.setCom('${appId}', 'JsonParametersMapperTable', JsonParametersMapperTable);