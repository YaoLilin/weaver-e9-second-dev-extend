"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Modal = _antd.Modal,
    message = _antd.message;
var _ecCom = ecCom,
    WeaTools = _ecCom.WeaTools;
var callApi = WeaTools.callApi;
var ApiConfigure = ecodeSDK.imp(ApiConfigure);

var ApiConfDialog =
/*#__PURE__*/
function (_React$Component) {
  _inherits(ApiConfDialog, _React$Component);

  function ApiConfDialog(props) {
    var _this;

    _classCallCheck(this, ApiConfDialog);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ApiConfDialog).call(this, props));

    _this.removeEmptyNameParam = function (params) {
      if (params) {
        params = params.filter(function (i) {
          return i.name;
        });
        params.forEach(function (i) {
          if (i.children) {
            i.children = _this.removeEmptyNameParam(i.children);
          }
        });
      }

      return params;
    };

    _this.removeEmptyNameParams = function () {
      var _this$props = _this.props,
          data = _this$props.data,
          onChange = _this$props.onChange;

      var newData = _objectSpread({}, data);

      var bodyParameters = newData.bodyParameters,
          queryParameters = newData.queryParameters,
          headerParameters = newData.headerParameters,
          returnParameters = newData.returnParameters;
      newData.bodyParameters = _this.removeEmptyNameParam(bodyParameters);
      newData.queryParameters = _this.removeEmptyNameParam(queryParameters);
      newData.headerParameters = _this.removeEmptyNameParam(headerParameters);
      newData.returnParameters = _this.removeEmptyNameParam(returnParameters);
      onChange(newData);
      return newData;
    };

    _this.saveData = function (callback) {
      var data = _this.removeEmptyNameParams();

      var params = {
        url: data.formData.url,
        method: data.formData.method,
        apiId: data.formData.apiId,
        name: data.formData.name,
        bodyType: data.formData.bodyType,
        bodyParameters: data.bodyParameters,
        queryParameters: data.queryParameters,
        headerParameters: data.headerParameters,
        returnParameters: data.returnParameters
      };

      if (!params.url) {
        message.error('请填写接口地址');
        callback(false);
        return;
      }

      if (!params.apiId) {
        message.error('请填写接口标识');
        callback(false);
        return;
      }

      $.ajax({
        url: '/api/second-dev/extend/apis',
        type: 'post',
        data: JSON.stringify(params),
        contentType: "application/json",
        success: function success(result) {
          callback(true);
        },
        error: function error(xhr, status, _error) {
          callback(false);
        }
      });
    };

    _this.handleOk = function () {
      _this.saveData(function (result) {
        if (result) {
          message.success('保存成功');

          _this.props.onOk();
        } else {
          message.error('保存失败');
        }
      });
    };

    _this.handleCancel = function () {
      _this.props.onCancel();
    };

    _this.handleChange = function (newData) {
      var onChange = _this.props.onChange;
      onChange(newData);
    };

    return _this;
  }

  _createClass(ApiConfDialog, [{
    key: "render",
    value: function render() {
      var _this$props2 = this.props,
          visible = _this$props2.visible,
          data = _this$props2.data;
      var footer = [React.createElement(Button, {
        onClick: this.handleCancel
      }, "\u53D6\u6D88"), React.createElement(Button, {
        type: 'primary',
        onClick: this.handleOk
      }, "\u4FDD\u5B58")];
      return React.createElement(Modal, {
        title: "\u63A5\u53E3\u914D\u7F6E",
        width: 1000,
        visible: visible,
        footer: footer,
        maskClosable: false,
        onOk: this.handleOk,
        onCancel: this.handleCancel
      }, React.createElement(ApiConfigure, {
        data: data,
        onChange: this.handleChange
      }));
    }
  }]);

  return ApiConfDialog;
}(React.Component);

ecodeSDK.exp(ApiConfDialog);