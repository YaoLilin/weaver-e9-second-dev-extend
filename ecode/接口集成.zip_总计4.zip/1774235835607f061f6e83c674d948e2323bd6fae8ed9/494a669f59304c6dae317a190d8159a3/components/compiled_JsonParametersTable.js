"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Input = _antd.Input,
    Select = _antd.Select,
    Button = _antd.Button,
    Table = _antd.Table,
    Switch = _antd.Switch,
    Icon = _antd.Icon,
    message = _antd.message;
var Option = Select.Option;
/**
 * props: {
 *     data:[],
 *     onChange : (data) => {},
 *     extendColumns?: [] | ((ctx) => []), // 扩展列（可选）。如果传函数，会注入内部操作方法，便于复用。
 *     resetFieldsOnTypeChange?: string[], // 当“参数类型”变化时，需要被重置的字段（可选）
 *     resetFieldValuesOnTypeChange?: object, // 字段重置值映射（可选），例如 { assignment: null, detailTable: '' }
 *     readonly?: boolean, // 只读模式（可选），为 true 时基础列不可编辑，隐藏添加/删除按钮
 * } ,
 * 仅支持配置 JSON 参数结构（名称/显示名称/必需/类型），不包含字段映射能力。
 */

var JsonParametersTable =
/*#__PURE__*/
function (_React$Component) {
  _inherits(JsonParametersTable, _React$Component);

  function JsonParametersTable(props) {
    var _this;

    _classCallCheck(this, JsonParametersTable);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(JsonParametersTable).call(this, props));

    _this.getAllExpandableIds = function (parameters) {
      var ids = [];

      if (!parameters || !Array.isArray(parameters)) {
        return ids;
      }

      parameters.forEach(function (param) {
        if (param.children && param.children.length > 0) {
          ids.push(param.id); // 递归收集子节点的ID

          ids.push.apply(ids, _toConsumableArray(_this.getAllExpandableIds(param.children)));
        }
      });
      return ids;
    };

    _this.typeOptions = {
      0: '字符串',
      1: '数字',
      2: '布尔',
      3: '对象',
      4: '数组'
    };

    _this.getColumns = function () {
      var readonly = _this.props.readonly;
      var baseColumns = [{
        title: '参数名称',
        dataIndex: 'name',
        key: 'name',
        className: 'param-name',
        render: function render(text, record) {
          if (readonly) {
            return React.createElement("div", {
              style: {
                minHeight: 32,
                lineHeight: '32px'
              }
            }, text);
          }

          return React.createElement("div", {
            style: {
              maxWidth: 250,
              display: 'flex',
              alignItems: 'center'
            }
          }, React.createElement(Input, {
            value: text,
            onChange: function onChange(e) {
              return _this.handleChange(record.id, 'name', e.target.value);
            },
            onBlur: function onBlur(e) {
              return _this.handleBlur(record.id, 'name', e.target.value);
            },
            placeholder: "\u53C2\u6570\u540D\u79F0"
          }), React.createElement(Icon, {
            type: "plus-circle",
            style: {
              textAlign: 'left',
              marginLeft: '10px',
              visibility: record.type === 3 || record.type === 4 ? 'visible' : 'hidden'
            },
            onClick: function onClick() {
              if (!text) {
                message.error('请先填写参数名称');
                return;
              }

              _this.handleAddParameter(record.id);
            }
          }));
        }
      }, {
        title: '显示名称',
        dataIndex: 'showName',
        key: 'showName',
        render: function render(text, record) {
          if (readonly) {
            return React.createElement("div", {
              style: {
                minHeight: 32,
                lineHeight: '32px'
              }
            }, text);
          }

          return React.createElement(Input, {
            style: {
              maxWidth: 250
            },
            value: text,
            onChange: function onChange(e) {
              return _this.handleChange(record.id, 'showName', e.target.value);
            },
            placeholder: "\u663E\u793A\u540D\u79F0"
          });
        }
      }, {
        title: '必需',
        dataIndex: 'operation',
        key: 'operation',
        render: function render(text, record) {
          return React.createElement("div", {
            style: {
              minHeight: 32,
              lineHeight: '32px'
            }
          }, React.createElement(Switch, {
            checked: record.required,
            disabled: readonly,
            onChange: function onChange(checked) {
              _this.handleChange(record.id, 'required', checked);
            }
          }));
        }
      }, {
        title: '参数类型',
        dataIndex: 'type',
        key: 'type',
        render: function render(text, record) {
          if (readonly) {
            return React.createElement("div", {
              style: {
                minHeight: 32,
                lineHeight: '32px'
              }
            }, _this.typeOptions[text] || '未知');
          }

          return React.createElement(Select, {
            value: text,
            onChange: function onChange(value) {
              return _this.handleChange(record.id, 'type', value);
            },
            style: {
              width: 120
            }
          }, React.createElement(Option, {
            value: 0
          }, "\u5B57\u7B26\u4E32"), React.createElement(Option, {
            value: 1
          }, "\u6570\u5B57"), React.createElement(Option, {
            value: 2
          }, "\u5E03\u5C14"), React.createElement(Option, {
            value: 3
          }, "\u5BF9\u8C61"), React.createElement(Option, {
            value: 4
          }, "\u6570\u7EC4"));
        }
      }];
      var extendColumns = [];

      if (typeof _this.props.extendColumns === 'function') {
        extendColumns = _this.props.extendColumns({
          handleChange: _this.handleChange,
          handleBlur: _this.handleBlur,
          props: _this.props
        }) || [];
      } else if (Array.isArray(_this.props.extendColumns)) {
        extendColumns = _this.props.extendColumns;
      }

      return [].concat(baseColumns, _toConsumableArray(extendColumns));
    };

    _this.handleExpand = function (expanded, record) {
      _this.setState(function (prevState) {
        var updatedExpandedRowKeys = _toConsumableArray(prevState.expandedRowKeys);

        if (expanded) {
          if (!updatedExpandedRowKeys.includes(record.id)) {
            updatedExpandedRowKeys.push(record.id);
          }
        } else {
          updatedExpandedRowKeys = updatedExpandedRowKeys.filter(function (key) {
            return key !== record.id;
          });
        }

        return {
          expandedRowKeys: updatedExpandedRowKeys
        };
      });
    };

    _this.handleAddParameter = function (parentId) {
      var newParameter = {
        id: Date.now() + '',
        name: '',
        chineseName: '',
        type: 0,
        // 设置默认值
        required: false,
        assignmentMethod: '',
        // 设置默认值
        value: '' // 设置默认值

      };
      var _this$props = _this.props,
          data = _this$props.data,
          onChange = _this$props.onChange;

      var newData = _this.addParameter(data, parentId, newParameter);

      var updatedExpandedRowKeys = _toConsumableArray(_this.state.expandedRowKeys);

      if (parentId !== null && !updatedExpandedRowKeys.includes(parentId)) {
        updatedExpandedRowKeys.push(parentId);
      }

      _this.setState({
        expandedRowKeys: updatedExpandedRowKeys
      });

      onChange(newData);
    };

    _this.handleDeleteParameters = function () {
      var selectedRowKeys = _this.state.selectedRowKeys;
      var _this$props2 = _this.props,
          data = _this$props2.data,
          onChange = _this$props2.onChange;

      var newData = _toConsumableArray(data); // 递归删除所有选中的参数（包括子参数）


      selectedRowKeys.forEach(function (id) {
        newData = _this.removeParameter(newData, id);
      }); // 清空选中状态

      _this.setState({
        selectedRowKeys: []
      });

      onChange(newData);
    };

    _this.removeParameter = function (parameters, id) {
      return parameters.filter(function (param) {
        // 如果当前参数就是要删除的参数，直接过滤掉（包括其所有子参数）
        if (param.id === id) {
          return false;
        } // 如果有子参数，递归处理子参数


        if (param.children && param.children.length > 0) {
          param.children = _this.removeParameter(param.children, id);
        }

        return true;
      });
    };

    _this.addParameter = function (parameters, parentId, newParameter) {
      if (parentId === null) {
        // 如果 parentId 为 null，直接添加到 parameters 数组中
        return [].concat(_toConsumableArray(parameters), [newParameter]);
      }

      return parameters.map(function (param) {
        if (param.id === parentId) {
          // 确保 children 存在
          if (!param.children) {
            param.children = [];
          }

          return _objectSpread({}, param, {
            children: [].concat(_toConsumableArray(param.children), [newParameter])
          });
        }

        if (param.children && param.children.length > 0) {
          return _objectSpread({}, param, {
            children: _this.addParameter(param.children, parentId, newParameter)
          });
        }

        return param;
      });
    };

    _this.updateParameter = function (parameters, id, field, value) {
      return parameters.map(function (param) {
        if (param.id === id) {
          return _objectSpread({}, param, _defineProperty({}, field, value));
        }

        if (param.children && param.children.length > 0) {
          return _objectSpread({}, param, {
            children: _this.updateParameter(param.children, id, field, value)
          });
        }

        return param;
      });
    };

    _this.findParameter = function (parameters, id) {
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = parameters[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var param = _step.value;

          if (param.id === id) {
            return param;
          }

          if (param.children && param.children.length > 0) {
            var found = _this.findParameter(param.children, id);

            if (found) {
              return found;
            }
          }
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return != null) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      return null;
    };

    _this.removeChildren = function (parameters, id) {
      return parameters.map(function (param) {
        if (param.id === id) {
          // 确保 children 存在
          if (!param.children) {
            param.children = [];
          }

          return _objectSpread({}, param, {
            children: null
          });
        }

        if (param.children && param.children.length > 0) {
          return _objectSpread({}, param, {
            children: _this.removeChildren(param.children, id)
          });
        }

        return param;
      });
    };

    _this.handleChange = function (id, field, value) {
      var _this$props3 = _this.props,
          data = _this$props3.data,
          onChange = _this$props3.onChange;

      var newParameters = _this.updateParameter(data, id, field, value); // 检查是否需要删除子参数


      if (field === 'type') {
        var currentParam = _this.findParameter(newParameters, id);

        if (currentParam && currentParam.type !== 3 && currentParam.type !== 4) {
          newParameters = _this.removeChildren(newParameters, id);
        } // 可选：确保在类型变化时，指定字段被重置（例如 mapper 场景：assignmentMethod/value）


        var resetFields = Array.isArray(_this.props.resetFieldsOnTypeChange) ? _this.props.resetFieldsOnTypeChange : [];
        var resetValues = _this.props.resetFieldValuesOnTypeChange || {};

        if (currentParam && resetFields.length > 0) {
          resetFields.forEach(function (f) {
            var v = Object.prototype.hasOwnProperty.call(resetValues, f) ? resetValues[f] : '';
            newParameters = _this.updateParameter(newParameters, id, f, v);
          });
        }
      }

      onChange(newParameters);
    };

    _this.handleBlur = function (id, field, value) {
      var _this$props4 = _this.props,
          data = _this$props4.data,
          onChange = _this$props4.onChange;
      var isDuplicate = false;

      if (field === 'name' && value !== '') {
        if (data.some(function (param) {
          return param.id === id;
        })) {
          isDuplicate = data.some(function (param) {
            return param.id !== id && param.name === value;
          });
        } else {
          var sameLevelParams = _this.getSameLevelParams(id, data);

          if (sameLevelParams) {
            isDuplicate = sameLevelParams.some(function (param) {
              return param.id !== id && param.name === value;
            });
          }
        }
      }

      if (isDuplicate) {
        var newParameters = _this.updateParameter(data, id, 'name', '');

        onChange(newParameters);
        message.error('参数名称重复，请重新输入');
      }
    };

    _this.state = {
      expandedRowKeys: [],
      selectedRowKeys: []
    };
    return _this;
  }
  /**
   * 递归收集所有有子节点的参数ID
   * @param {Array} parameters 参数数组
   * @returns {Array} 所有有子节点的参数ID数组
   */


  _createClass(JsonParametersTable, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      // 初始化时展开所有有子节点的行
      var data = this.props.data;
      var allExpandableIds = this.getAllExpandableIds(data);

      if (allExpandableIds.length > 0) {
        this.setState({
          expandedRowKeys: allExpandableIds
        });
      }
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      // 当数据变化时，如果数据不同，重新展开所有有子节点的行
      var data = this.props.data;

      if (prevProps.data !== data) {
        var allExpandableIds = this.getAllExpandableIds(data);
        this.setState({
          expandedRowKeys: allExpandableIds
        });
      }
    } // 参数类型选项映射

  }, {
    key: "getSameLevelParams",
    value: function getSameLevelParams(id, data) {
      var _this2 = this;

      var result = null;
      data.forEach(function (i) {
        if (result) {
          return;
        }

        if (i.id === id) {
          result = data;
          return;
        }

        if (i.children && i.children.length > 0) {
          var findResult = _this2.getSameLevelParams(id, i.children);

          if (findResult) {
            result = findResult;
          }
        }
      });
      return result;
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var _this$state = this.state,
          expandedRowKeys = _this$state.expandedRowKeys,
          selectedRowKeys = _this$state.selectedRowKeys;
      var _this$props5 = this.props,
          data = _this$props5.data,
          readonly = _this$props5.readonly;
      return React.createElement("div", null, !readonly && React.createElement("div", {
        style: {
          paddingBottom: 10
        }
      }, React.createElement(Button, {
        type: "primary",
        onClick: function onClick() {
          return _this3.handleAddParameter(null);
        }
      }, "\u6DFB\u52A0\u53C2\u6570"), React.createElement(Button, {
        type: "danger",
        onClick: function onClick() {
          return _this3.handleDeleteParameters();
        },
        disabled: selectedRowKeys.length === 0,
        style: {
          marginLeft: 10
        }
      }, "\u5220\u9664\u53C2\u6570")), React.createElement(Table, {
        className: 'a669f59304c6dae317a190d8159a3-table',
        columns: this.getColumns(),
        dataSource: data,
        pagination: {
          defaultPageSize: 20,
          showSizeChanger: true,
          pageSizeOptions: ['10', '20', '50', '100'],
          showTotal: function showTotal(total) {
            return "\u5171 ".concat(total, " \u6761");
          }
        },
        showHeader: true,
        rowKey: "id",
        size: "small",
        indentSize: 20,
        childrenColumnName: "children",
        expandedRowKeys: expandedRowKeys,
        onExpand: this.handleExpand,
        rowSelection: readonly ? null : {
          selectedRowKeys: selectedRowKeys,
          onChange: function onChange(selectedRowKeys) {
            return _this3.setState({
              selectedRowKeys: selectedRowKeys
            });
          }
        }
      }));
    }
  }]);

  return JsonParametersTable;
}(React.Component);

ecodeSDK.exp(JsonParametersTable);
ecodeSDK.setCom('${appId}', 'JsonParametersTable', JsonParametersTable);