"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _ecCom = ecCom,
    WeaInput = _ecCom.WeaInput,
    WeaFormItem = _ecCom.WeaFormItem,
    WeaBrowser = _ecCom.WeaBrowser;
var _antd = antd,
    Select = _antd.Select;
var Option = Select.Option;

var ParamValue =
/*#__PURE__*/
function (_React$Component) {
  _inherits(ParamValue, _React$Component);

  function ParamValue() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, ParamValue);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ParamValue)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _this.handleChange = function (value) {
      var onChange = _this.props.onChange;
      onChange(value);
    };

    _this.getInputComponent = function () {
      var _this$props = _this.props,
          type = _this$props.type,
          value = _this$props.value;

      if (type === 0) {
        return _this.getSelectFieldBrowser(value);
      } else if (type === 1) {
        return _this.getSystemVarBrowser(value);
      } else if (type === 2) {
        return React.createElement(WeaInput, {
          viewAttr: "3",
          value: value,
          onChange: _this.handleChange
        });
      }
    };

    return _this;
  }

  _createClass(ParamValue, [{
    key: "getSystemVarBrowser",
    value: function getSystemVarBrowser(value) {
      var _this2 = this;

      return React.createElement(WeaBrowser, {
        type: 161,
        viewAttr: "3",
        title: '系统变量',
        inputStyle: {
          width: 200
        },
        replaceDatas: [{
          id: value.id ? value.id : '',
          name: value.name ? value.name : ''
        }],
        onChange: function onChange(ids, names, datas) {
          _this2.handleChange({
            id: ids,
            name: names
          });
        },
        dataParams: {
          f_weaver_belongto_usertype: 0,
          type: 'browser.param_sys_var'
        },
        conditionDataParams: {
          fielddbtype: 'browser.param_sys_var',
          type: 'browser.param_sys_var'
        },
        completeParams: {
          fielddbtype: "browser.param_sys_var"
        },
        conditionURL: '/api/public/browser/condition/',
        hasAdvanceSerach: true
      });
    }
  }, {
    key: "getSelectFieldBrowser",
    value: function getSelectFieldBrowser(value) {
      var _this3 = this;

      var formId = this.props.formId;
      var replaceDatas = [];

      if (value) {
        replaceDatas = [{
          id: value.id,
          name: value.name
        }];
      }

      return React.createElement(WeaBrowser, {
        type: 161,
        viewAttr: "3",
        title: '选择表单字段',
        inputStyle: {
          width: 200
        },
        replaceDatas: replaceDatas,
        onChange: function onChange(ids, names, datas) {
          _this3.handleChange({
            id: ids,
            name: names
          });
        },
        dataParams: {
          f_weaver_belongto_usertype: 0,
          type: 'browser.select_bill_field',
          billId: formId
        },
        conditionDataParams: {
          fielddbtype: 'browser.select_bill_field',
          type: 'browser.select_bill_field'
        },
        completeParams: {
          fielddbtype: "browser.select_bill_field"
        },
        conditionURL: '/api/public/browser/condition/',
        hasAdvanceSerach: true
      });
    }
  }, {
    key: "render",
    value: function render() {
      return React.createElement(React.Fragment, null, this.getInputComponent());
    }
  }]);

  return ParamValue;
}(React.Component);

ecodeSDK.exp(ParamValue);