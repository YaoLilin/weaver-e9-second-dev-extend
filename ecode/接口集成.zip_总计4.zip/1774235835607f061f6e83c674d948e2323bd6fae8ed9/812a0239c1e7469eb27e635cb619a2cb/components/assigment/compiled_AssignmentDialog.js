"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Input = _antd.Input,
    Button = _antd.Button,
    Modal = _antd.Modal,
    message = _antd.message,
    Tag = _antd.Tag;
var FormFieldSelector = ecodeSDK.imp(FormFieldSelector);
var SystemParamSelector = ecodeSDK.imp(SystemParamSelector);
/**
 * 赋值对话框组件
 * props: {
 *     visible: boolean,  // 是否显示对话框
 *     value: object,  // 赋值数据 { method, value }
 *     data: object,  // 赋值所需数据 { formFields, systemParams }
 *     loadingFields: boolean,  // 是否正在加载字段数据
 *     onOk: (assignment) => {},  // 确定回调
 *     onCancel: () => {},  // 取消回调
 * }
 * 
 */

var AssignmentDialog =
/*#__PURE__*/
function (_React$Component) {
  _inherits(AssignmentDialog, _React$Component);

  function AssignmentDialog(props) {
    var _this;

    _classCallCheck(this, AssignmentDialog);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(AssignmentDialog).call(this, props));

    _this.buildStateFromValue = function (assignmentValue) {
      var method = assignmentValue && assignmentValue.method ? assignmentValue.method : 1;
      var detailValue = assignmentValue && assignmentValue.value ? assignmentValue.value : {};
      var workflowField = detailValue.workflowField || {};
      return {
        selectedMethod: method,
        value: {
          workflowField: {
            isMainTable: workflowField.isMainTable !== undefined ? workflowField.isMainTable : true,
            detailTableNum: workflowField.detailTableNum || null,
            fieldName: workflowField.fieldName || '',
            displayName: workflowField.displayName || ''
          },
          fixedValue: method === 3 ? detailValue.value || '' : '',
          selectedSystemParamCode: method === 2 ? detailValue.value || '' : ''
        }
      };
    };

    _this.setSelectedMethod = function (method) {
      // 切换赋值方式时，不清空当前选择
      _this.setState({
        selectedMethod: method
      });
    };

    _this.getCurrentAssignmentDisplay = function () {
      var _this$state = _this.state,
          selectedMethod = _this$state.selectedMethod,
          value = _this$state.value;
      var _this$props$data = _this.props.data,
          data = _this$props$data === void 0 ? {} : _this$props$data;
      var formFields = data.formFields || {};
      var systemParams = data.systemParams || [];

      if (selectedMethod === 1) {
        var workflowField = value.workflowField || {};
        var fields = workflowField.isMainTable ? formFields.mainFields || [] : ((formFields.details || []).find(function (d) {
          return d.detailNum === workflowField.detailTableNum;
        }) || {}).fields || [];
        var found = fields.find(function (f) {
          return f.fieldName === workflowField.fieldName;
        });
        var nameText = found ? found.labelName ? found.labelName + '(' + found.fieldName + ')' : found.fieldName : workflowField.displayName || workflowField.fieldName;

        if (nameText) {
          var tagLabel = workflowField.isMainTable ? '主表' : workflowField.detailTableNum ? '明细' + workflowField.detailTableNum : '';
          return React.createElement("span", {
            style: {
              display: 'inline-flex',
              alignItems: 'center'
            }
          }, tagLabel ? React.createElement(Tag, {
            style: {
              marginRight: 6
            }
          }, tagLabel) : null, React.createElement("span", null, nameText));
        }

        return '';
      }

      if (selectedMethod === 2) {
        var _found = systemParams.find(function (s) {
          return s.code === value.selectedSystemParamCode;
        });

        return _found ? '系统参数：' + _found.name : '';
      }

      if (selectedMethod === 3) {
        return value.fixedValue ? '固定值：' + value.fixedValue : '';
      }

      return '';
    };

    _this.handleOk = function () {
      var _this$state2 = _this.state,
          selectedMethod = _this$state2.selectedMethod,
          value = _this$state2.value;
      var _this$props = _this.props,
          onOk = _this$props.onOk,
          _this$props$data2 = _this$props.data,
          data = _this$props$data2 === void 0 ? {} : _this$props$data2;
      var formFields = data.formFields || {};
      var systemParams = data.systemParams || [];
      var assignment = null;

      if (selectedMethod === 1) {
        var workflowField = value.workflowField || {};

        if (!workflowField.fieldName) {
          if (onOk) {
            onOk(null);
          }

          return;
        }

        var fields = workflowField.isMainTable ? formFields.mainFields || [] : ((formFields.details || []).find(function (d) {
          return d.detailNum === workflowField.detailTableNum;
        }) || {}).fields || [];
        var found = fields.find(function (f) {
          return f.fieldName === workflowField.fieldName;
        });
        var displayName = found ? found.labelName ? found.labelName + '(' + found.fieldName + ')' : found.fieldName : workflowField.displayName || workflowField.fieldName;
        assignment = {
          method: 1,
          value: {
            workflowField: {
              isMainTable: workflowField.isMainTable === true,
              detailTableNum: workflowField.isMainTable ? null : workflowField.detailTableNum,
              fieldName: workflowField.fieldName,
              displayName: displayName
            },
            value: ''
          }
        };
      } else if (selectedMethod === 2) {
        if (!value.selectedSystemParamCode) {
          if (onOk) {
            onOk(null);
          }

          return;
        }

        var _found2 = systemParams.find(function (s) {
          return s.code === value.selectedSystemParamCode;
        });

        if (!_found2) {
          message.error('请选择有效的系统参数');
          return;
        }

        assignment = {
          method: 2,
          value: {
            value: _found2.code
          }
        };
      } else if (selectedMethod === 3) {
        if (!value.fixedValue) {
          if (onOk) {
            onOk(null);
          }

          return;
        }

        assignment = {
          method: 3,
          value: {
            value: value.fixedValue
          }
        };
      } else {
        message.error('请选择赋值方式');
        return;
      }

      if (onOk) {
        onOk(assignment);
      }
    };

    _this.handleClear = function () {
      var _this$state3 = _this.state,
          selectedMethod = _this$state3.selectedMethod,
          value = _this$state3.value;
      var currentWorkflowField = value.workflowField || {
        isMainTable: true,
        detailTableNum: null,
        fieldName: '',
        displayName: ''
      };
      var nextValue = {
        workflowField: currentWorkflowField,
        fixedValue: value.fixedValue || '',
        selectedSystemParamCode: value.selectedSystemParamCode || ''
      };

      if (selectedMethod === 1) {
        nextValue.workflowField = _objectSpread({}, currentWorkflowField, {
          fieldName: '',
          displayName: ''
        });
      } else if (selectedMethod === 2) {
        nextValue.selectedSystemParamCode = '';
      } else if (selectedMethod === 3) {
        nextValue.fixedValue = '';
      }

      _this.setState({
        value: nextValue
      });
    };

    _this.renderAssignModalRight = function () {
      var _this$state4 = _this.state,
          selectedMethod = _this$state4.selectedMethod,
          value = _this$state4.value;
      var _this$props2 = _this.props,
          _this$props2$data = _this$props2.data,
          data = _this$props2$data === void 0 ? {} : _this$props2$data,
          _this$props2$loadingF = _this$props2.loadingFields,
          loadingFields = _this$props2$loadingF === void 0 ? false : _this$props2$loadingF;
      var formFields = data.formFields || {};
      var systemParams = data.systemParams || [];

      if (selectedMethod === 1) {
        var workflowField = value.workflowField || {};
        var selectorData = {
          mainFields: formFields.mainFields || [],
          details: formFields.details || [],
          isMainTable: workflowField.isMainTable === true,
          detailTableNum: workflowField.detailTableNum || null
        };
        var formFieldSelectorValue = workflowField || {};
        return React.createElement(FormFieldSelector, {
          data: selectorData,
          value: formFieldSelectorValue,
          loadingFields: loadingFields,
          onChange: function onChange(v) {
            _this.setState({
              value: _objectSpread({}, value, {
                workflowField: v
              })
            });
          }
        });
      }

      if (selectedMethod === 2) {
        return React.createElement(SystemParamSelector, {
          systemParams: systemParams,
          selectedParamCode: value.selectedSystemParamCode,
          loading: false,
          onParamSelect: function onParamSelect(paramCode) {
            _this.setState({
              value: _objectSpread({}, value, {
                selectedSystemParamCode: paramCode
              })
            });
          }
        });
      }

      if (selectedMethod === 3) {
        return React.createElement("div", null, React.createElement("div", {
          style: {
            marginBottom: 6
          }
        }, "\u56FA\u5B9A\u503C"), React.createElement(Input, {
          style: {
            width: '100%'
          },
          value: value.fixedValue,
          placeholder: "\u8BF7\u8F93\u5165\u56FA\u5B9A\u503C",
          onChange: function onChange(e) {
            _this.setState({
              value: _objectSpread({}, value, {
                fixedValue: e.target.value
              })
            });
          }
        }));
      }

      return null;
    };

    _this.state = _this.buildStateFromValue(_this.props.value);
    return _this;
  }

  _createClass(AssignmentDialog, [{
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      // 当 visible 变为 true 时，初始化状态并加载系统参数
      if (this.props.visible && !prevProps.visible) {
        this.setState(this.buildStateFromValue(this.props.value));
      } else if (this.props.visible && prevProps.value !== this.props.value) {
        this.setState(this.buildStateFromValue(this.props.value));
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var _this$props3 = this.props,
          visible = _this$props3.visible,
          onCancel = _this$props3.onCancel;
      var selectedMethod = this.state.selectedMethod;
      var currentDisplay = this.getCurrentAssignmentDisplay();
      return React.createElement(Modal, {
        title: "\u8D4B\u503C",
        visible: visible,
        onOk: this.handleOk,
        onCancel: onCancel,
        width: 720,
        footer: [React.createElement(Button, {
          key: "clear",
          onClick: this.handleClear
        }, "\u6E05\u9664"), React.createElement(Button, {
          key: "cancel",
          onClick: onCancel
        }, "\u53D6\u6D88"), React.createElement(Button, {
          key: "ok",
          type: "primary",
          onClick: this.handleOk
        }, "\u786E\u5B9A")]
      }, React.createElement("div", {
        style: {
          marginBottom: 12
        }
      }, "\u5F53\u524D\u9009\u62E9\uFF1A", currentDisplay || '未选择'), React.createElement("div", {
        style: {
          display: 'flex',
          minHeight: 280
        }
      }, React.createElement("div", {
        style: {
          width: 160,
          borderRight: '1px solid #eee',
          paddingRight: 12
        }
      }, React.createElement("div", {
        style: {
          marginBottom: 8,
          color: '#888'
        }
      }, "\u8D4B\u503C\u65B9\u5F0F"), React.createElement("div", {
        style: {
          display: 'flex',
          flexDirection: 'column',
          gap: 8
        }
      }, React.createElement(Button, {
        type: selectedMethod === 1 ? 'primary' : 'default',
        onClick: function onClick() {
          return _this2.setSelectedMethod(1);
        }
      }, "\u8868\u5355\u5B57\u6BB5"), React.createElement(Button, {
        type: selectedMethod === 2 ? 'primary' : 'default',
        onClick: function onClick() {
          return _this2.setSelectedMethod(2);
        }
      }, "\u7CFB\u7EDF\u53C2\u6570"), React.createElement(Button, {
        type: selectedMethod === 3 ? 'primary' : 'default',
        onClick: function onClick() {
          return _this2.setSelectedMethod(3);
        }
      }, "\u56FA\u5B9A\u503C"))), React.createElement("div", {
        style: {
          flex: 1,
          paddingLeft: 16,
          minWidth: 0
        }
      }, this.renderAssignModalRight())));
    }
  }]);

  return AssignmentDialog;
}(React.Component);

ecodeSDK.exp(AssignmentDialog);
ecodeSDK.setCom('${appId}', 'AssignmentDialog', AssignmentDialog);