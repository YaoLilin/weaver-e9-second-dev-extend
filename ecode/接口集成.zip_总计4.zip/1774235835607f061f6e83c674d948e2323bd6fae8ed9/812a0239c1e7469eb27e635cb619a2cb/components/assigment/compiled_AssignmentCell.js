"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Button = _antd.Button;
var _antd2 = antd,
    Tag = _antd2.Tag;
var AssignmentDialog = ecodeSDK.imp(AssignmentDialog);
var PropTypes = window.PropTypes;
/**
 * 接口参数赋值组件，用于在接口参数配置页面中，为接口参数赋值
 *
 * @example
 * <AssignmentCell
 *     record={{ id: '1', type: 0, children: [] }}
 *     value={{
 *         method: 1,
 *         value: {
 *             workflowField: {
 *                 isMainTable: true,
 *                 detailTableNum: 1,
 *                 fieldName: 'lx',
 *                 displayName: '日期(rq)'
 *             },
 *             value: ''
 *         }
 *     }}
 *     data={{
 *         formFields: {
 *             mainFields: [{ fieldName: 'lx', labelName: '类型', fieldType: '输入框' }],
 *             details: [{ detailNum: 1, fields: [{ fieldName: 'lx', labelName: '类型', fieldType: '输入框' }] }]
 *         },
 *         systemParams: [{ code: 'CREATOR', name: '流程创建人' }]
 *     }}
 *     loadingFields={false}
 *     onChangeAssignment={(id, field, value) => {}}
 * />
 */

var AssignmentCell =
/*#__PURE__*/
function (_React$Component) {
  _inherits(AssignmentCell, _React$Component);

  function AssignmentCell(props) {
    var _this;

    _classCallCheck(this, AssignmentCell);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(AssignmentCell).call(this, props));

    _this.openModal = function () {
      _this.setState({
        modalVisible: true
      });
    };

    _this.closeModal = function () {
      _this.setState({
        modalVisible: false
      });
    };

    _this.handleOk = function (assignment) {
      var _this$props = _this.props,
          record = _this$props.record,
          onChangeAssignment = _this$props.onChangeAssignment;

      if (onChangeAssignment) {
        onChangeAssignment(record.id, 'assignment', assignment);
      }

      _this.closeModal();
    };

    _this.buildDisplay = function () {
      var _this$props2 = _this.props,
          value = _this$props2.value,
          data = _this$props2.data;
      var systemParams = data && data.systemParams ? data.systemParams : [];
      var display = '';
      var displayNode = '';

      if (value) {
        if (value.display) {
          display = value.display;
          displayNode = display;
        } else if (value.method && value.value) {
          var method = value.method;
          var detailValue = value.value;

          if (method === 1 && detailValue.workflowField) {
            var workflowField = detailValue.workflowField;
            var nameText = workflowField.displayName || workflowField.fieldName || '';
            var tagLabel = '';

            if (workflowField.isMainTable === true) {
              tagLabel = '主表';
            } else if (workflowField.detailTableNum) {
              tagLabel = '明细' + workflowField.detailTableNum;
            }

            display = (tagLabel + (nameText ? ' ' + nameText : '')).trim();
            displayNode = React.createElement("span", null, tagLabel ? React.createElement(Tag, null, tagLabel) : null, nameText);
          } else if (method === 2 && detailValue.value) {
            var found = (systemParams || []).find(function (s) {
              return s.code === detailValue.value;
            });
            var paramName = found ? found.name : detailValue.value;
            display = '系统参数：' + paramName;
            displayNode = display;
          } else if (method === 3 && detailValue.value) {
            display = '固定值：' + detailValue.value;
            displayNode = display;
          }
        }
      }

      return {
        display: display,
        displayNode: displayNode
      };
    };

    _this.state = {
      modalVisible: false
    };
    return _this;
  }
  /**
   * @typedef {Object} AssignmentCellProps
   * @property {Object} record 当前行记录
   * @property {Object} value 赋值数据
   * @property {Object} data 赋值所需数据
   * @property {boolean} loadingFields 字段加载状态
   * @property {Function|null} onChangeAssignment 赋值结果回写方法
   */


  _createClass(AssignmentCell, [{
    key: "render",
    value: function render() {
      var _this$props3 = this.props,
          record = _this$props3.record,
          loadingFields = _this$props3.loadingFields,
          value = _this$props3.value,
          data = _this$props3.data;
      var modalVisible = this.state.modalVisible;

      if (record.type === 3) {
        return null;
      }

      if (record.type === 4 && record.children && record.children.length > 0) {
        return null;
      }

      var displayInfo = this.buildDisplay();
      return React.createElement("div", {
        style: {
          display: 'flex',
          alignItems: 'center'
        }
      }, React.createElement(Button, {
        size: "small",
        onClick: this.openModal
      }, "\u8D4B\u503C"), React.createElement("div", {
        style: {
          marginLeft: 8,
          flex: 1,
          minWidth: 0,
          whiteSpace: 'normal',
          wordBreak: 'break-all'
        },
        title: displayInfo.display
      }, displayInfo.displayNode || displayInfo.display), React.createElement(AssignmentDialog, {
        visible: modalVisible,
        value: value,
        data: data,
        loadingFields: loadingFields,
        onOk: this.handleOk,
        onCancel: this.closeModal
      }));
    }
  }]);

  return AssignmentCell;
}(React.Component);

if (PropTypes) {
  AssignmentCell.propTypes = {
    /** 当前行记录 */
    record: PropTypes.object,

    /** 赋值数据 */
    value: PropTypes.object,

    /** 赋值所需数据 */
    data: PropTypes.object,

    /** 字段加载状态 */
    loadingFields: PropTypes.bool,

    /** 赋值结果回写方法 */
    onChangeAssignment: PropTypes.func
  };
}

AssignmentCell.defaultProps = {
  record: {},
  value: null,
  data: {},
  loadingFields: false,
  onChangeAssignment: null
}; // 应用id：812a0239c1e7469eb27e635cb619a2cb

ecodeSDK.exp(AssignmentCell);
ecodeSDK.setCom('${appId}', 'AssignmentCell', AssignmentCell);